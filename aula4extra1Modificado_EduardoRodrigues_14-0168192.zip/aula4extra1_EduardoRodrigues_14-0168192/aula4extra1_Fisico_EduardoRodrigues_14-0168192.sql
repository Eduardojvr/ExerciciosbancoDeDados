-- --------     << aula4extra1 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 05/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 05/06/2019
--   => Criacao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- -----------------------------------------------------------------

create database if not exists aula4extra1;
use aula4extra1;

CREATE TABLE AREACONHECIMENTO (
    codArea int auto_increment not null,
    tipoArea varchar(30) not null,
	constraint areaConhecimento_pk PRIMARY KEY (codArea)
)engine = InnoDB auto_increment=1;

CREATE TABLE DEPARTAMENTO (
    codDepartamento int auto_increment not null,
    codArea int not null,
    nome varchar(30) not null,
	constraint departamento_pk PRIMARY KEY (codDepartamento),
    constraint departamento_areaConhecimento_fk foreign key (codArea) references AREACONHECIMENTO(codArea)
)engine = InnoDB auto_increment=1;

CREATE TABLE DISCIPLINA (
    codDisciplina int auto_increment not null,
    codDepartamento int not null,
    nome varchar(30) not null,
    qtdCredito int(2) not null,
    constraint disciplina_pk PRIMARY KEY (codDisciplina),
    constraint disciplina_departamento_fk foreign key (codDepartamento) references DEPARTAMENTO(codDepartamento)
)engine = InnoDB auto_increment=1;

CREATE TABLE CURSO (
    codCurso int auto_increment not null,
    codArea int not null,
    codDepartamento int not null,
    nome varchar(30) not null,
    qtdCredito int(3) not null,
	constraint curso_pk PRIMARY KEY (codCurso),
    constraint curso_areaConhecimento_fk foreign key (codArea) references AREACONHECIMENTO(codArea),
    constraint curso_departamento_fk foreign key (codDepartamento) references DEPARTAMENTO(codDepartamento)
)engine = InnoDB auto_increment=1;

CREATE TABLE GRADEHORARIA (
    diaSemana varchar(15) not null,
	codDisciplina int not null,
    turma char(2) not null,
    codCurso int not null,
    horaInicioAula time not null,
    horaFimAula time not null,
    constraint gradeHoraria_pk primary key (diaSemana, codDisciplina, turma),
    constraint gradeHoraria_curso_fk foreign key (codCurso) references CURSO(codCurso),
    constraint gradeHoraria_disciplina_fk foreign key (codDisciplina) references DISCIPLINA(codDisciplina)
)engine = InnoDB;

CREATE TABLE depende (
    codDisciplina int not null,
    codDisciplinaRequisito int not null,
    constraint depende_disciplina_fk foreign key (codDisciplina)references DISCIPLINA(codDisciplina),
    constraint depende_disciplinaRequisito_fk foreign key (codDisciplinaRequisito) references DISCIPLINA(codDisciplina)
)engine = InnoDB;

-- drop database aula4extra1;