-- --------     << aula4extra1 >>     ------------
-- 
--                    SCRIPT DE DEFINICAO (DDL)
-- 
-- Data Criacao ...........: 05/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 05/06/2019
--   => Deleção de tabelas da base de dados
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- -----------------------------------------------------------------

use aula4extra1;

DROP TABLE depende;
DROP TABLE GRADEHORARIA;
DROP TABLE CURSO;
DROP TABLE DISCIPLINA;
DROP TABLE DEPARTAMENTO;
DROP TABLE AREACONHECIMENTO;
