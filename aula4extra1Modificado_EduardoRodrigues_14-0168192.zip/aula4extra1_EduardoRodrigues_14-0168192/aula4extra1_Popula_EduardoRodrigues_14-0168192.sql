-- --------     << aula4extra1 >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- Data Criacao ...........: 05/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4extra1
-- 
-- Data Ultima Alteracao ..: 05/06/2019
--   => Inserção de dados na base
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4extra1;

INSERT INTO AREACONHECIMENTO VALUES ('1','Ciências Exatas'),
									('2','Artes'),
									('3','Engenharia');
                                        
INSERT INTO DEPARTAMENTO VALUES 	('1', '1','Departamento de matemática'),
									('2','3','Departamento de software'),
									('3', '2','Departamento de artes');
                                    
INSERT INTO DISCIPLINA VALUES 		('1', '1','Matemática aplicada' ,'4'),
									('2', '3', 'Arte Moderna', '2'),
									('3', '2','Projeto Integrador 2','6'),
                                    ('4', '2','TCC 1','4'),
                                    ('5', '2','TCC 2','6'),
                                    ('6', '2', 'Projeto Integrador 1', '4'),
                                    ('7', '3', 'Arte Moderna 2', '2');
                                    
INSERT INTO CURSO VALUES 			('1', '1','1', 'Matemática', '210'),
									('2', '2','3', 'Artes Cênicas', '180'),
                                    ('3', '3', '2', 'Engenharia de Software', '240');
                                    
INSERT INTO GRADEHORARIA VALUES 	('Segunda' ,'1', 'A','1','10:00:00','12:00:00' ),
									('Segunda', '3', 'B','3','08:00:00','09:50:00'),
                                    ('Sexta', '2', 'C','2','20:00:00','21:50:00');
                                    
INSERT INTO depende VALUES 			('3','6'),
									('5','4'),
									('7','2');                                    