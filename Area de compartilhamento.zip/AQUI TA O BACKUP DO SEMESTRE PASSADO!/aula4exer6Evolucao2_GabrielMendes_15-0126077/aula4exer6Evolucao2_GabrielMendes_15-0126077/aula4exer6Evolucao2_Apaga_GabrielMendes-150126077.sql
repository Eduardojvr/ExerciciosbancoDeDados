﻿-- --------     << aula4exer6Evolucao2 >>     ------------ --
--                                                         --
--                    SCRIPT DE APAGA (DDL)                --
--                                                         --
-- Data Criacao ...........: 21/04/2018                    --
-- Autor(es) ..............: Gabriel Braga Mendes          --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula4exer6Evolucao2           --
--                                                         --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 09 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE aula4Exer6Evolucao2;

DROP TABLE INFRACAO;
DROP TABLE TIPOINFRACAO;
DROP TABLE AGENTE;
DROP TABLE LOCAL;
DROP TABLE VEICULO;
DROP TABLE MODELO;
DROP TABLE CATEGORIA;
DROP TABLE TELEFONE;
DROP TABLE PESSOA;