-- --------     << bd2Phenix >>     ------------ --
--                                                         --
--                    SCRIPT DE CRIACAO (DML)              --
--                                                         --
-- Data Criacao ...........: 07/05/2018                    --
-- Autor(es) ..............: Gabriel Braga Mendes          --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: bd2Phenix                     --
--                                                         --
--                                                         --
--                                                         --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 06 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE bd2Phenix;

DROP TABLE TRABALHA;
DROP TABLE ENGENHEIRO;
DROP TABLE ATIVIDADE;
DROP TABLE PROJETO;
DROP TABLE TELEFONE;
DROP TABLE CLIENTE;
