-- --------     << aula4exer6 >>     ------------------------------- --
--                                                                   --
--                    SCRIPT DE CRIACAO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 17/04/2018                              --
-- Autor(es) ..............: Guilherme Marques Rosa                  --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: exer6                                   --
--                                                                   --
-- PROJETO => Deleta as relações                                     --
--                                                                   --
--                                                                   --
--                                                                   --
-- ----------------------------------------------------------------- --
delete from INFRACAO;
delete from AGENTE;
delete from VEICULO;
delete from fone;
delete from PESSOAEPOSSE;
