-- --------     << aula4exer6_Apaga >>     ------------------------ --
--                                                                   --
--                    SCRIPT DE CRIACAO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 17/04/2018                              --
-- Autor(es) ..............: Filipe Dias Soares Lima                 --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula4exer6_Apaga                       --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 08 Tabelas                                             --
--                                                                   --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula4exer6evolucao1Fisico;

DROP TABLE categoria;
DROP TABLE modelo;
DROP TABLE veiculo;
DROP TABLE pessoa;
DROP TABLE agente;
DROP TABLE lugar;
DROP TABLE telefone;
DROP TABLE infracao;
