﻿-- --------         << aula4exer7 >>          ------------ --
--                                                         --
--                    SCRIPT DE REMOCAO (DDL)              --
--                                                         --
-- Data Criacao ...........: 24/04/2018                    --
-- Autor(es) ..............: William Silva de Almeida      --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula4exer7                    --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 09 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE aula4exer7;

DROP TABLE TRABALHO;
DROP TABLE SUPERVISAO;
DROP TABLE DEPENDENTE;
DROP TABLE LOCALIZACAO;
DROP TABLE SUPERVISOR;
DROP TABLE PROJETO;
DROP TABLE DEPARTAMENTO;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;

