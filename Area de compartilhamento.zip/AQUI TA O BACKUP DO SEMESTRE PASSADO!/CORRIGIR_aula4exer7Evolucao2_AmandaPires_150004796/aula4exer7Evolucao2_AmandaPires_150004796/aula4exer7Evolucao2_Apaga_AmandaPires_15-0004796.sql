
﻿-- --------     << aula4exer7evolucao2 >>     ------------ --
--                                                         --
--                    SCRIPT DE DELETE (DDL)              --
--                                                         --
-- Data Criacao ...........: 03/05/2018                    --
-- Autor(es) ..............: Amanda Vieira Pires
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula4exer7evolucao2           --
--                                                         --
--                                                         --
--                                                         --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 06 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE aula4exer7evolucao2;

DROP TABLE trabalha;
DROP TABLE localizacao;
DROP TABLE PROJETO;
DROP TABLE DEPENDENTE;
DROP TABLE EMPREGADO;
DROP TABLE DEPARTAMENTO;