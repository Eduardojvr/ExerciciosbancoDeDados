﻿-- --------     << aula7exer2_Evolucao3 >>    ------------ --
--                                                         --
--                    SCRIPT DE REMOCAO(DML)	             --
--                                                         --
-- Data Criacao ...........: 07/06/2018                    --
-- Autor(es) ..............: Lucas Hiroshi Horinouchi      --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula7exer2_Evolucao3          --
--                                                         --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 08 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

use aula7exer2_Evolucao3;

drop table RECEITA;
drop table POSSUI;
drop table VENDA;
drop table PERFUME;
drop table MEDICAMENTO;
drop table PRODUTO;
drop table TELEFONE;
drop table FABRICANTE;