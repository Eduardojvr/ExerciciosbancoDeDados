﻿-- --------     << aula4exer7evolucao1 >>     ------------ --
--                                                         --
--                    SCRIPT DE REMOCAO (DDL)              --
--                                                         --
-- Data Criacao ...........: 01/05/2018                    --
-- Autor(es) ..............: Djorkaeff Alexandre Vilela    --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula4exer7evolucao1           --
--                                                         --
--                                                         --
--         => 07 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE aula4exer7evolucao1;

DROP TABLE TRABALHO;
DROP TABLE DEPENDENTE;
DROP TABLE LOCALIZACAO;
DROP TABLE PROJETO;
DROP TABLE DEPARTAMENTO;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
