-- 									<<revisaoP1 - Apaga>>
-- Base de dados para controle de escalas de plantonistas da secretaria de segurança.
-- Data de criação: 11/05/2019
-- Nome base de dados: bdPlantao
-- Descrição: 
--   => Script de deleção de tabelas da base de dados bdPlantao
--   => Quantidade de tabelas: 07
-- Banco de dados: mysql
-- Autor: Eduardo Júnio Veloso Rodrigues

use bdPlantao;

drop table possui;

drop table LOCACAO;

drop table CIDADE;

drop table TIPOFORMACAO;

drop table PLANTONISTA;

drop table SUPERVISOR;

drop table EMPREGADO;