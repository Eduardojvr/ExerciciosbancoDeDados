-- 									<<revisaoP1 - POPULA>>
-- Base de dados para controle de escalas de plantonistas da secretaria de segurança.
-- Data de criação: 11/05/2019
-- Nome base de dados: bdPlantao
-- Descrição: 
--   => Script de inserção de dados na base de dados bdPlantão
--   => Quantidade de tabelas: 07
-- Banco de dados: mysql
-- Autor: Eduardo Júnio Veloso Rodrigues

use bdPlantao;

INSERT INTO EMPREGADO
VALUES	('Ana Martins', 'F', 1234,'2000-12-12'),
		('Pedro Guilherme', 'M', 4321, '1990-12-12'),
        ('Julia Martins', 'F', 5678, '1985-12-12'),
        ('Guilherme Martins', 'M', 9999,'1950-12-12'),
		('Jõao Pedro', 'M', 3333, '1978-12-12'),
        ('Mateus Santos', 'M', 2834, '1978-12-12');

INSERT INTO SUPERVISOR
VALUES	(11111111111, 1234),
		(22222222222, 4321),
        (33333333333, 5678);
        
INSERT INTO PLANTONISTA
VALUES	(11111111111, 3333),
		(11111111111, 9999),
        (33333333333, 2834);
        
INSERT INTO CIDADE
VALUES	(01,  'Asa norte', 12333333),
		(02, 'Taguatinga', 343534434),
        (03, 'Águas Claras', 6765756456);

INSERT INTO TIPOFORMACAO
VALUES	(99, 'Tec Segurança'),
		(88, 'Segurança armada'),
        (77, 'Guarda Costas');

INSERT INTO LOCACAO
VALUES	('2019-06-12', 01, 3333),
		('2019-05-12', 02, 9999),
        ('2019-08-12', 03, 2834);
        
INSERT INTO possui
VALUES	(3333, 99),
		(9999, 88),
        (2834, 77);
        
        