-- 									<<revisaoP1 - DEFINICAO>>
-- Base de dados para controle de escalas de plantonistas da secretaria de segurança.
-- Data de criação: 11/05/2019
-- Nome base de dados: bdPlantao
-- Descrição: 
--   => Script de definição da base de dados
--   => Quantidade de tabelas: 07
-- Banco de dados: mysql
-- Autor: Eduardo Júnio Veloso Rodrigues

create database if not exists bdPlantao;

use bdPlantao;

CREATE TABLE EMPREGADO (
    nome VARCHAR(30) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    matricula BIGINT(11) NOT NULL,
    dtNascimento date NOT NULL,
    constraint empregado_PK primary key (matricula)
);

CREATE TABLE SUPERVISOR (
    cpf BIGINT(11) NOT NULL,
    matricula BIGINT(11) NOT NULL,
    constraint supervisor_PK primary key (cpf),
    constraint matricula_FK foreign key (matricula) references EMPREGADO(matricula)
);

CREATE TABLE PLANTONISTA (
    cpf BIGINT(11) NOT NULL,
    matricula BIGINT(11) NOT NULL,
    constraint plantonista_PK PRIMARY KEY (matricula, cpf),
    constraint plantonista_empregado_FK foreign key (matricula) references EMPREGADO(matricula),
    constraint plantonista_supervisor_FK foreign key (cpf) references SUPERVISOR(cpf)
);

CREATE TABLE TIPOFORMACAO (
    codFormacao INT NOT NULL,
    descFormacao VARCHAR(30) NOT NULL,
    constraint tipoformacao_PK primary key (codFormacao)
);

CREATE TABLE CIDADE (
    codCidade INT NOT NULL,
    nomeCidade VARCHAR(30) NOT NULL,
    tamanhoCidade float NOT NULL,
    constraint cidade_pk primary key (codCidade)
);


CREATE TABLE LOCACAO (
    data DATE NOT NULL,
    codCidade INT NOT NULL,
    matricula BIGINT(11) NOT NULL,
    constraint locacao_PK PRIMARY KEY (data, matricula),
    constraint locacao_cidade_FK foreign key (codCidade) references CIDADE(codCidade),
    constraint locacao_plantonista_FK foreign key (matricula) references PLANTONISTA(matricula)
);

CREATE TABLE possui (
    matricula BIGINT(11) NOT NULL,
    codFormacao INT NOT NULL,	
    constraint possui_plantonista_FK foreign key (matricula) references PLANTONISTA(matricula),
    constraint possui_formacao_FK foreign key (codFormacao) references TIPOFORMACAO(codFormacao)
);

#drop database bdPlantao;