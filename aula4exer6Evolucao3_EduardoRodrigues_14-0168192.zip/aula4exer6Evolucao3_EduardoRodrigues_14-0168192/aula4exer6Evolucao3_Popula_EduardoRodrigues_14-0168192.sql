-- --------     << aula4exer6evolucao3 >>     ------------
-- 
--                    SCRIPT PARA POPULAR TABELAS
-- 
-- Data Criacao ...........: 27/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6evolucao3
-- 
-- Data Ultima Alteracao ..: 27/04/2019
--   => Comandos para inserção de dados nas tabels da base de dados
-- -----------------------------------------------------------------


use  aula4exer6evolucao3;

-- Insere proprietários
insert into PROPRIETARIO  (cpf, nome, logradouro, numero, cidade, bairro, uf, complemento, cep, sexo, dtNascimento)
values (11111111111, 'Ana Maria Braga', 'Casa da Ana Maria',  6, 'São Paulo', 'São Paulo', 'SP','Minha casa',7123456, 'F', '1900-12-23' ),
			(22222222222, 'Pedro Martins', 'Casa do Martins',  10, 'Brasília', 'Lago norte', 'DF', 'Casa do Martins', 700000, 'M', '1990-02-12' ),
            (33333333333, 'João', 'Casa do João',  34, 'Taguatinga', 'Vicente Pires', 'DF', 'Casa 34 B',2345674, 'M', '2000-10-10' );

-- Insere telefones
insert into telefone (cpf, telefone)
values (11111111111, 1123452345),
		   (22222222222, 6143215421),
		   (33333333333, 61987654321);

-- Insere modelos
insert into MODELO (codModelo, nomeModelo)
values (123456, 'Hyundai I30'),
		   (234567, 'Tyota Hilux'), 
		   (345678, 'Chevrolet Cruze');

-- Insere proprietários
insert into CATEGORIA ( codCategoria, nomeCategoria)
values (98, 'AUTOMOVEL'),
		   (76, 'MOTOCICLETA'),
		   (54, 'CAMIONETE');

 -- Insere proprietários
insert into VEICULO (placa, numeroChassi, cor, codModelo, codCategoria, ano, cpf )
values ('JHA9090', '1234567', 'prata', 123456, 98, 2010, 11111111111),
		   ('JHA1234', '6536454', 'preto', 234567, 54, 2016, 22222222222), 
           ('JHA8765', '2954356', 'branco', 345678, 98, 2012, 33333333333);

-- Insere proprietários
insert into LOCALIZACAO (codLocal, latitude, longitude, velocidadePermitida)
values ('LOC123', 99, 22, 80),
		   ('LOC234', 10, 12, 90),
	       ('LOC8762', 46, 56, 100);

-- Insere proprietários
insert into AGENTE(matricula, nome, dtContratacao)
values (1234567, 'AGENTE UM', '1980-02-20'),
		   (7654321, 'AGENTE DOIS', '1990-03-12'),
           (9876546, 'AGENTE TRES', '2000-06-12');
           
-- Insere proprietários
insert into TIPO_INFRACAO (codInfracao, descricao, valor)
values (22, 'Excesso de velocidade', '198.34'),
		   (23, 'Não dar preferência para pedestre', '220.34'),
           (24, 'Estacionar sobre calçada', '90.34');

-- Insere proprietários
insert into INFRACAO (placa, dataHora, codInfracao, codLocal, velocidadeAferida, matricula)
values ('JHA9090', current_timestamp, 22, 'LOC123', 90, 1234567),
           ('JHA1234', current_timestamp, 23, 'LOC234', NULL, 7654321),
           ('JHA8765', current_timestamp, 24, 'LOC8762', NULL, 9876546);
