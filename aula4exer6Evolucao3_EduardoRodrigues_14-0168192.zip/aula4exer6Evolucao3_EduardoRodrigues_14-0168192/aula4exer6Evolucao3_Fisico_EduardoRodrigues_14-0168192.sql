-- --------     << aula4exer6evolucao3 >>     ------------
-- 
--                    SCRIPT DE DEFINIÇÃO (DDL)
-- 
-- Data Criacao ...........: 27/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6evolucao3
-- 
-- Data Ultima Alteracao ..: 27/04/2019
--   => Criacao de nova tabela INFRACAO
--   => Modificação do nome da base de dados, especificação da engine (motor de armazenamento) e 
--  	   inserção de auto incremento na tabela INFRACAO 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer6evolucao3;

use aula4exer6evolucao3;

CREATE TABLE PROPRIETARIO (
    cpf BIGINT(11) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    uf CHAR(2) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    cep INT(8) NOT NULL,
    sexo CHAR(1) NOT NULL,
    dtNascimento DATE NOT NULL,
CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
)engine = InnoDB;

CREATE TABLE telefone (
    cpf BIGINT(11) NOT NULL,
    telefone BIGINT(11) NOT NULL,
CONSTRAINT telefone_PK PRIMARY KEY (cpf, telefone),
CONSTRAINT telefone_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf)
)engine = InnoDB;

CREATE TABLE MODELO (
    codModelo INT(6) NOT NULL,
    nomeModelo VARCHAR(50) NOT NULL,
CONSTRAINT MODELO_PK PRIMARY KEY (codModelo)
)engine = InnoDB;

CREATE TABLE CATEGORIA (
    codCategoria INT(2) NOT NULL,
    nomeCategoria VARCHAR(50) NOT NULL,
CONSTRAINT CATEGORIA_PK PRIMARY KEY (codCategoria)
)engine = InnoDB;

CREATE TABLE VEICULO (
    placa CHAR(7) NOT NULL,
    numeroChassi CHAR(17) NOT NULL UNIQUE,
    cor VARCHAR(20) NOT NULL,
    codModelo INT(6) NOT NULL,
    codCategoria INT(2) NOT NULL,
    ano INT(4) NOT NULL,
    cpf BIGINT(11) NOT NULL,
CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf)
    REFERENCES PROPRIETARIO (cpf),
CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codModelo)
    REFERENCES MODELO (codModelo),
CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codCategoria)
    REFERENCES CATEGORIA (codCategoria)
)engine = InnoDB;

CREATE TABLE LOCALIZACAO (
    codLocal VARCHAR(20) NOT NULL,
    latitude DECIMAL(8,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    velocidadePermitida INT(3) NOT NULL,
CONSTRAINT LOCALIZACAO_PK PRIMARY KEY (codLocal)
)engine = InnoDB;

CREATE TABLE AGENTE (
    matricula BIGINT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    dtContratacao DATE NOT NULL,
CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
)engine = InnoDB;

CREATE TABLE TIPO_INFRACAO (
    codInfracao INT NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    valor DECIMAL(6,2) NOT NULL,
CONSTRAINT TIPO_INFRACAO_PK PRIMARY KEY (codInfracao)
)engine = InnoDB;

CREATE TABLE INFRACAO(
    idInfracao BIGINT auto_increment  NOT NULL,
    placa CHAR(7) NOT NULL,
    dataHora TIMESTAMP NOT NULL,
    codInfracao INT NOT NULL,
    codLocal VARCHAR(20) NOT NULL,
    velocidadeAferida INT(3),
    matricula BIGINT NOT NULL,
CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa)
    REFERENCES VEICULO (placa),
CONSTRAINT INFRACAO_TIPO_INFRACAO_FK FOREIGN KEY (codInfracao)
    REFERENCES TIPO_INFRACAO (codInfracao),
CONSTRAINT INFRACAO_LOCALIZACAO_FK FOREIGN KEY (codLocal)
    REFERENCES LOCALIZACAO (codLocal),
CONSTRAINT INFRACAO_AGENTE_FK FOREIGN KEY (matricula)
    REFERENCES AGENTE (matricula)
)engine = InnoDB auto_increment=1;

#drop database aula4exer6evolucao3;