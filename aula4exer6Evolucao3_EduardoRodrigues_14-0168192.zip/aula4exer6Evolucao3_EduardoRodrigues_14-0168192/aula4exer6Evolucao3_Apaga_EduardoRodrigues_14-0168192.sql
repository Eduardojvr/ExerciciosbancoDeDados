-- --------     << aula4exer6evolucao3 >>     ------------
-- 
--              SCRIPT PARA DELEÇÃO DE DADOS DAS TABELAS DA BASE DE DADOS
-- 
-- Data Criacao ...........: 27/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6evolucao3
-- 
-- Data Ultima Alteracao ..: 27/04/2019
--   => Comandos para inserção de dados nas tabels da base de dados
-- -----------------------------------------------------------------

use aula4exer6Evolucao3;


-- Apaga apenas os dados das tabelas
delete from telefone;
delete from INFRACAO;
delete from VEICULO;
delete from PROPRIETARIO;
delete from LOCALIZACAO;
delete from TIPO_INFRACAO;
delete from AGENTE;
delete from CATEGORIA;
delete from MODELO;


-- Apaga as tabelas sem apagar a base de dados
drop table telefone;
drop table INFRACAO;
drop table VEICULO;
drop table PROPRIETARIO;
drop table LOCALIZACAO;
drop table TIPO_INFRACAO;
drop table AGENTE;
drop table CATEGORIA;
drop table MODELO;
