 /*
	Script de criação da estrutura da base dados aula4exer6Evolucao2. 
    Aluno: Eduardo Júnio Veloso Rodrigues
    Matrícula: 14/0168192
	Atividade: Aula 4 exercício 6 Evolução 2 - Base de dados para controle de infrações.
    Nível: Físico

*/


create database aula4exer6Evolucao2;

use aula4exer6Evolucao2;


CREATE TABLE MODELO (
    nomeModelo varchar(50) not null,
    codModelo int(6)not null,
    constraint MODELO_PK primary key (codModelo)
);

CREATE TABLE PROPRIETARIO (
    cpf bigint(11) not null,
    nome varchar(50) not null,
    logradouro varchar(100) not null,
    numero int not null ,
    complemento varchar(100) not null,
    bairro varchar(50) not null,
    cidade varchar(50) not null,
    uf char(2) not null,
    cep int(5) not null,
    sexo char(1) not null,
    dtNascimento date not null,
    constraint PROPRIETARIO_PK primary key (cpf)
);

CREATE TABLE CATEGORIA (
    nomeCategoria varchar(50) not null,
    codCategoria int(2) not null,
    constraint CATEGORIA_PK primary key (codCategoria)
);


CREATE TABLE VEICULO (
    placa char(7) not null,
    numeroChassi char(17) not null,
    cor varchar(20) not null,
    codModelo int(6) not null,
    codCategoria int(2) not null,
    ano date not null,
    cpf bigint(11) not null,
	constraint VEICULO_PK primary key (placa),
    constraint MODELO_FK foreign key (codModelo) references MODELO(codModelo),
	constraint CATEGORIA_FK foreign key (codCategoria) references CATEGORIA(codCategoria),
	constraint PROPRIETARIO_FK foreign key (cpf) references PROPRIETARIO(cpf),
    constraint VEICULO_UC unique (numeroChassi)
);

CREATE TABLE TIPO_INFRACAO (
    codInfracao int not null,
    valor decimal(6, 2) not null,
    descricao varchar(100) not null,
	constraint TIPOINFRACAO_PK primary key (codInfracao)

);

CREATE TABLE LOCAL (
    codLocal varchar(20) not null,
    latitude decimal(8, 6) not null,
    longitude decimal(9, 6) not null,
    velocidadePermitida int(3) not null,
	constraint LOCAL_PK primary key (codLocal)

);

CREATE TABLE AGENTE (
    dtContratacao date not null,
    nome varchar(50) not null,
    matricula bigint(5) not null,
	constraint AGENTE_PK primary key (matricula)

);

CREATE TABLE INFRACAO (
	idInfracao bigint not null auto_increment,
    placa char(7) not null,
    dataHora timestamp not null,
    codInfracao int not null,
    matricula bigint not null,
    velocidadeAferida int(3),
    codLocal varchar(20)  not null,
    constraint INFRACAO_PK primary key (idInfracao),
    constraint INFRACAO_VEICULO_FK foreign key (placa)  references VEICULO(placa),	
	constraint INFRACAO_TIPOINFRACAO_FK foreign key (codInfracao)  references TIPO_INFRACAO(codInfracao),
	constraint INFRACAO_AGENTE_FK foreign key (matricula)  references AGENTE(matricula),
	constraint INFRACAO_LOCAL_FK foreign key (codLocal)  references LOCAL(codLocal)
);


CREATE TABLE telefone (
    cpf bigint(11) not null,
    telefone bigint(11) not null,
	constraint TELEFONE_PK primary key (cpf, telefone),
	constraint TELEFONE_FK foreign key (cpf)  references PROPRIETARIO(cpf)
);

show tables;

drop database aula4exer6Evolucao2;



