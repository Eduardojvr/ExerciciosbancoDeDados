-- --------     << aula4exer5EvolucaoFinal >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- date Criacao ...........: 06/05/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula4exer5EvolucaoFinal
-- 
-- date Ultima Alteracao ..: 06/05/2019
--   => Criacao da base de dados e tabelas
-- -----------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS aula4exer5EvolucaoFinal;
USE aula4exer5EvolucaoFinal;

CREATE TABLE IF NOT EXISTS MEDICO (
	crm bigint(8) NOT NULL,
    nome varchar(30) NOT NULL,
    CONSTRAINT MEDICO_PK PRIMARY KEY(crm)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS ESPECIALIDADE (
	idEspecialidade int(2) NOT NULL,
    nomeEspecialidade varchar(30) NOT NULL,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY(idEspecialidade)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS possui (
	crm bigint(8) NOT NULL,
    idEspecialidade int(2) NOT NULL,
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY(crm) REFERENCES MEDICO(crm),
    CONSTRAINT possui_ESPECIALIDADE_FK FOREIGN KEY(idEspecialidade) REFERENCES ESPECIALIDADE(idEspecialidade)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS PACIENTE (
	cpf bigint(11) NOT NULL,
    nome varchar(30) NOT NULL,
	idade int(3) NOT NULL,
	sexo enum('M','F') NOT NULL,
	cidade varchar(15) NOT NULL,
	bairro varchar(15) NOT NULL,
	estado varchar(2) NOT NULL,
	complemento varchar(50) NOT NULL,
	cep int(8) NOT NULL,
    CONSTRAINT PACIENTE_PK PRIMARY KEY(cpf)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS telefone(
	cpf bigint(11) NOT NULL,
	telefone bigint(12),
    constraint TELEFONE_CPF_PK FOREIGN KEY (cpf) references PACIENTE(cpf)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS CONSULTA (
	cpf bigint(11) NOT NULL,
    crm bigint(8) NOT NULL,
    data date NOT NULL,
    CONSTRAINT CONSULTA_PK PRIMARY KEY (data, crm, cpf),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY(cpf) REFERENCES PACIENTE(cpf),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY(crm) REFERENCES MEDICO(crm)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS RECEITA (
	cpf bigint(11) NOT NULL,
	crm bigint(8) NOT NULL,
    data date NOT NULL,
    idReceita bigint(8) NOT NULL auto_increment,
    posologia varchar(50) NOT NULL,
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA_cpf_FK FOREIGN KEY(cpf) REFERENCES CONSULTA(cpf),
    CONSTRAINT RECEITA_CONSULTA_crm_FK FOREIGN KEY(crm) REFERENCES CONSULTA(crm),
	CONSTRAINT RECEITA_CONSULTA_data_FK FOREIGN KEY(data) REFERENCES CONSULTA(data)
)engine = InnoDB auto_increment=1;

CREATE TABLE IF NOT EXISTS MEDICAMENTO (
	codMedicamento bigint(5) NOT NULL,
	nomeMedicamento varchar(30) NOT NULL,
	descricao varchar(30) NOT NULL,
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY(codMedicamento)
)engine = InnoDB;

CREATE TABLE IF NOT EXISTS contem (
	codMedicamento bigint(5) NOT NULL,
    idReceita bigint(8) NOT NULL,
    CONSTRAINT contem_RECEITA_FK FOREIGN KEY(idReceita) REFERENCES RECEITA(idReceita),
    CONSTRAINT contem_MEDICAMENTO_FK FOREIGN KEY(codMedicamento) REFERENCES MEDICAMENTO(codMedicamento)
)engine = InnoDB;

#drop database aula4exer5EvolucaoFinal;