-- --------     << aula4exer5EvolucaoFinal >>     ------------
-- 
--                    SCRIPT DE INSERÇÃO NA BASE DE DADOS
-- 
-- date Criacao ...........: 01/05/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula4exer5EvolucaoFinal
-- 
-- date Ultima Alteracao ..: 06/05/2019
--   => Criacao das inserções
-- -----------------------------------------------------------------

USE aula4exer5EvolucaoFinal;

INSERT INTO MEDICO 
VALUES	(12345678,'Joao da Silva'),
		(21735629,'Maria das Neves'),
        (34362367,'Paula Martins');

INSERT INTO ESPECIALIDADE 
VALUES	(01,'Cardiologista'),
		(02,'Pediatra'),
		(03,'Geral');

INSERT INTO possui
VALUES 	(12345678,01),
		(21735629,02),
        (34362367,03);

INSERT INTO PACIENTE 
VALUES	(19653412555,'Ana Sousa',55,'F','Sobradinho','Bairro Quase OK','DF','Condominio aqui',73644532),
		(46562454665,'Paula Soares',34,'F','Sobradinho','Bairro Quase la','DF','Condominio 123',17356421),
		(45234645657,'Marta Melo',24,'F','Sobradinho','Bairro bom','DF','Condominio terra',282315224);

    
INSERT INTO telefone
Values	(19653412555, 6123455432),
		(46562454665, 6198762453),
		(45234645657, 6198986543);
        
INSERT INTO CONSULTA
VALUES	(19653412555, 12345678,'2019-04-25'),
		(46562454665, 21735629,'2019-06-22'),
		(45234645657, 34362367,'2019-01-25');
        
INSERT INTO MEDICAMENTO 
VALUES	(00001,'Anti-dor-de-cabeca','Elimina a dor de cabeca'),
		(00002,'Dorflex','Elimina a dor de cabeca'),
		(00003,'Dipirona','Elimina a dor de cabeca');


INSERT INTO RECEITA
VALUES	(19653412555, 12345678, '2019-01-25', 1,'Duas vezes ao dia'),
		(46562454665, 21735629, '2019-01-25', 2,'tre vezes ao dia'),
        (45234645657, 34362367, '2019-01-25', 3,'quatro vezes ao dia');

INSERT INTO contem
VALUES	(00001, 1),
		(00002, 2),
        (00003, 3);
