-- --------     << aula4exer5EvolucaoFinal >>     ------------
-- 
--                    SCRIPT DE DELEÇÃO
-- 
-- date Criacao ...........: 01/05/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ....: aula4exer5EvolucaoFinal
-- 
-- date Ultima Alteracao ..: 06/05/2019
--   => Criacao das instrucoes de deleção de tabelas da base de dados

-- -----------------------------------------------------------------
USE aula4exer5EvolucaoFinal;

drop table possui;
drop table contem;
drop table RECEITA;
drop table CONSULTA;
drop table MEDICAMENTO;
drop table ESPECIALIDADE;
drop table MEDICO;
drop table telefone;
drop table PACIENTE;