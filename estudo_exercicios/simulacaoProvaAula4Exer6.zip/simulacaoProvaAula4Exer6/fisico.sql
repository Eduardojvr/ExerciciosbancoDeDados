-- Script de definição (DDL)
-- Base de dados: simulacaoProva
-- 09 tabelas

create database if not exists simulacaoProva;
use simulacaoProva;


CREATE TABLE TIPOINFRACAO (
    descInfracao varchar(30) NOT NULL,
    codInfracao int  NOT NULL,
    valorInfracao decimal(7,2) NOT NULL,
	constraint tipoinfracao_PK PRIMARY KEY (codInfracao)
) engine= InnoDB;

CREATE TABLE CATEGORIA (
    codCategoria int(2) NOT NULL,
    descModelo varchar(30) NOT NULL,
	constraint categoria_PK PRIMARY KEY (codCategoria)
) engine= InnoDB;

CREATE TABLE MODELO (
    descModelo varchar(30) NOT NULL,
    codModelo int(6) NOT NULL,
	constraint modelo_PK PRIMARY KEY (codModelo)
) engine= InnoDB;

CREATE TABLE AGENTE (
    tmpServico int NOT NULL,
    dtContratacao date NOT NULL,
    nome varchar(30) NOT NULL,
    matriculaFuncional varchar(8) NOT NULL,
    constraint agente_PK PRIMARY KEY (matriculaFuncional)
) engine= InnoDB;

CREATE TABLE PROPRIETARIO (
    cpf bigint(11) NOT NULL,
    sexo enum('M', 'F') NOT NULL,
    dtNasc date NOT NULL,
    bairro varchar(30) NOT NULL,
    cidade varchar(30) NOT NULL,
    estado varchar(2) NOT NULL,
    constraint proprietario_PK PRIMARY KEY (cpf)
) engine= InnoDB;

CREATE TABLE LOCAL (
    codLocal int NOT NULL,
    latitude float NOT NULL,
    longitude float NOT NULL,
    velPermitida int NOT NULL,
    constraint local_PK PRIMARY KEY (codLocal)
) engine= InnoDB;

CREATE TABLE telefone (
    cpf bigint(11) NOT NULL,
    telefone bigint(11) NOT NULL,
    constraint telefone_FK foreign key (cpf) references PROPRIETARIO(cpf)
) engine= InnoDB;

CREATE TABLE VEICULO (
    placa varchar(7) NOT NULL,
    chassi varchar(15) NOT NULL,
    cor varchar(20) NOT NULL,
    anoFabricacao int NOT NULL,
    codCategoria int(2) NOT NULL,
    codModelo int(6) NOT NULL,
    cpf bigint(11) NOT NULL,
	constraint veiculo_PK PRIMARY KEY (placa),
	constraint veiculo_UK unique (chassi),
	constraint veiculo_proprietario_FK foreign key (cpf) references PROPRIETARIO(cpf),
	constraint veiculo_categoria_FK foreign key (codCategoria) references CATEGORIA(codCategoria),
	constraint veiculo_modelo_FK foreign key (codModelo) references MODELO(codModelo)
) engine= InnoDB;

CREATE TABLE INFRACAO (
    idInfracao int NOT NULL auto_increment,
    dtHora datetime NOT NULL,
    velAferida int(3),
    matriculaFuncional varchar(8) NOT NULL,
    codInfracao int NOT NULL,
    codLocal int NOT NULL,
    placa varchar(7) NOT NULL,
    constraint infracao_PK PRIMARY KEY (idInfracao)
) engine= InnoDB auto_increment=1;

#drop database simulacaoProva;
 