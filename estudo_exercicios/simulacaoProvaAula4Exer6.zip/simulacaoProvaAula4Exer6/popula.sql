-- Script popula (DML)
-- Base de dados: simulacaoProva
-- 09 tabelas

use simulacaoProva;

insert into TIPOINFRACAO
VALUES	('Sinal', 123 ,'198'),
		('Calcada', 234 ,'346'),
		('Faixa', 345 ,'456');
        

insert into CATEGORIA
VALUES	(01, 'Passeio'),
		(02, 'Motocicleta'),
		(03, 'Tranporte');
        
insert into MODELO
VALUES	('Gol', 111111),
		('Palio', 222222),
		('I30', 333333);
        
insert into AGENTE
VALUES	(10, '2000-12-12', 'Joao', 12345),
		(11, '1990-12-12', 'Pedro', 23456),
		(12, '1980-12-12', 'Marcos', 34567);
        
insert into PROPRIETARIO
VALUES	(11111111111, 'M', '2000-12-12', '513', 'asa norte', 'DF'),
		(22222222222, 'M', '1982-12-12', 'qnd', 'taguatinga', 'DF'),
		(33333333333, 'M', '1972-12-12', 'rua 12', 'vicente pires', 'DF');
        
        
insert into LOCAL
VALUES	(99, 1234.23, 2343, 90),
		(88, 4343.22, 24524, 80),
		(55, 1234.25, 24542, 60);
        

insert into telefone
VALUES	(11111111111, 613333444),
		(22222222222, 6166665555),
		(33333333333, 6133779988);
        
insert into VEICULO
VALUES	('JHA1234','DF23YUY4','prata', 2019, 01, 111111, 11111111111),
		('JHG4567','DVSFD7','preto', 2019, 01, 222222, 22222222222),
		('AHR1366','SDFDFUI23','azul', 2019, 01, 333333, 33333333333);
        
insert into INFRACAO
VALUES	(1,current_timestamp,29, 12345, 123, 99, 'JHA1234'),
		(2,current_timestamp,0, 23456, 123, 99, 'JHG4567'),
		(3,current_timestamp,120, 34567, 123, 99, 'AHR1366');
        
        
        