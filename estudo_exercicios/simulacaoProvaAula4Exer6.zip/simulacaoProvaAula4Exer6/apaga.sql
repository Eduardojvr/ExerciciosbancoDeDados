-- Script popula (DML)
-- Base de dados: simulacaoProva
-- 09 tabelas

use simulacaoProva;

drop table INFRACAO;
drop table VEICULO;
drop table telefone;
drop table PROPRIETARIO;
drop table LOCAL;
drop table AGENTE;
drop table TIPOINFRACAO;
drop table MODELO;
drop table CATEGORIA;