-- --------     << aula4exer6EvoluçãoFinal >>     ------------
-- 
--                    SCRIPT PARA POPULAR TABELAS
-- 
-- Data Criacao ...........: 29/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6EvoluçãoFinal
-- 
-- Data Ultima Alteracao ..: 06/05/2019
--   => Comandos para inserção de dados nas tabelas da base de dados
-- -----------------------------------------------------------------

USE aula4exer6EvoluçãoFinal;

INSERT IGNORE INTO MODELO (codModelo, descModelo) VALUES (111111, 'GOL MI'), (111112, 'GOL 1.8'), (211111, 'UNO CS');

INSERT IGNORE INTO CATEGORIA (codCategoria, descCategoria) VALUES (11, 'AUTOMÓVEL'), (12, 'MOTOCICLETA'), (13, 'CAMINHÃO');

INSERT IGNORE INTO PROPRIETARIO (cpf, nome, sexo, dtNascimento, rua, numero, complemento, bairro, cidade, siglaEstado) VALUES 
('11111111111', 'João da Silva', 'M', '1950-01-01', '1 norte', 1, 'casa branca', 'Águas Claras', 'Brasília', 'DF'), 
('22222222222', 'Maria da Silva', 'F', '1960-04-24', '1 norte', 1, 'casa branca', 'Águas Claras', 'Brasília', 'DF'), 
('33333333333', 'Pedro da Silva', 'M', '1990-05-05', '1 norte', 1, 'casa branca', 'Águas Claras', 'Brasília', 'DF');

INSERT IGNORE INTO telefone (cpf, telefone) VALUES ('11111111111', '912345678'), ('22222222222', '923456789'), ('33333333333', '934567891');

INSERT IGNORE INTO VEICULO (placa, chassi, corPredominante, anoFabricacao, codModelo, cpf, codCategoria) VALUES 
('PQW1234', 'SDFSDSFSDF231231223123', 'Preto', '2019', 111111, '11111111111', 11), 
('PQW1221', 'EMFWMEFIOM132312390909', 'Branco', '2019', 111112, '22222222222', 11), 
('PQW1222', 'MVFJDKVFJVD98289322313', 'Vermelho', '2019', 211111, '33333333333', 11);

INSERT IGNORE INTO LOCAL (codLocal, latitude, longitude, velocidadePermitida) VALUES 
(1231, '1231231234', '3453453453', 110), 
(1232, '1231231233', '3534534535', 50), 
(1234, '1313231231', '3454353452', 80);

INSERT IGNORE INTO AGENTE (matricula, nome, dtContratacao) VALUES 
('546445', 'Marcos Pereira', '2015-01-07'), 
('543923', 'Ana Maria Marcone', '2017-05-02'), 
('324223', 'Paula Abreu', '2010-10-11');

INSERT IGNORE INTO TIPOINFRACAO (codTipoInfracao, descInfracao, valor) VALUES 
(123, 'AVANÇO DE SINAL VERMELHO', 643.20), 
(321, 'EXCESSO DE VELODIDADE ACIMA DE 20%', 1002.23), 
(212, 'EXCESSO DE VELODIDADE ABAIXO DE 20%', 843.34);

INSERT IGNORE INTO INFRACAO (idInfracao, dtHoraInfracao, velocidadeAferida, codTipoInfracao, codLocal, placa, matricula) VALUES 
(111, '2019-03-20 15:02:54', null, 123, 1232, 'PQW1234', '546445'), 
(132, '2019-02-12 09:34:12', 97, 321, 1234, 'PQW1222', '543923'), 
(153, '2019-02-20 07:01:00', 125, 212, 1231, 'PQW1221', '324223');
