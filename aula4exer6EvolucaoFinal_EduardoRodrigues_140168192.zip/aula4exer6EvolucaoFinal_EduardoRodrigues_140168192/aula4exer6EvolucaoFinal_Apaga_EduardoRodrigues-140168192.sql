-- --------     << aula4exer6EvoluçãoFinal >>     ------------
-- 
--          SCRIPT PARA DELEÇAO DAS TABELAS DA BASE DE DADOS
-- 
-- Data Criacao ...........: 29/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6EvoluçãoFinal
-- 
-- Data Ultima Alteracao ..: 06/05/2019
--   => Comandos para definição da base de dados
-- -----------------------------------------------------------------

USE aula4exer6EvoluçãoFinal;

DROP TABLE IF EXISTS INFRACAO;

DROP TABLE IF EXISTS TIPOINFRACAO;

DROP TABLE IF EXISTS AGENTE;

DROP TABLE IF EXISTS LOCAL;

DROP TABLE IF EXISTS VEICULO;

DROP TABLE IF EXISTS telefone;

DROP TABLE IF EXISTS PROPRIETARIO;

DROP TABLE IF EXISTS CATEGORIA;

DROP TABLE IF EXISTS MODELO;