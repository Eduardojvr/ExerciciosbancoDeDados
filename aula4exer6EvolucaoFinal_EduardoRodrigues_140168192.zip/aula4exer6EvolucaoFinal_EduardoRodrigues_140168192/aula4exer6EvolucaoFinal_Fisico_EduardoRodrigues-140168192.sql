-- --------     << aula4exer6EvoluçãoFinal >>     ------------
-- 
--                SCRIPT PARA DEFINIÇAO DA BASE DE DADOS
-- 
-- Data Criacao ...........: 29/04/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de dados(nome) ...: aula4exer6EvoluçãoFinal
-- 
-- Data Ultima Alteracao ..: 06/05/2019
--   => Comandos para definição da base de dados
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer6EvoluçãoFinal
DEFAULT CHARACTER SET utf8mb4
DEFAULT COLLATE utf8mb4_general_ci;

USE aula4exer6EvoluçãoFinal;

CREATE TABLE IF NOT EXISTS MODELO (
    codModelo INT(6) NOT NULL,
    descModelo VARCHAR(20) NOT NULL,
    CONSTRAINT MODELO_PK PRIMARY KEY (codModelo)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS CATEGORIA (
    codCategoria INT(2) NOT NULL,
    descCategoria VARCHAR(20) NOT NULL,
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (codCategoria)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS PROPRIETARIO (
    cpf bigint(11) NOT NULL,
    nome CHAR(30) NOT NULL,
    sexo ENUM('M', 'F') NOT NULL,
    dtNascimento DATE NOT NULL,
    rua VARCHAR(20) NOT NULL,
    numero INT(2) NOT NULL,
    complemento VARCHAR(30) NOT NULL,
    bairro VARCHAR(20) NOT NULL,
    cidade VARCHAR(20) NOT NULL,
    siglaEstado CHAR(2) NOT NULL,
    CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS telefone (
    cpf bigint(11) NOT NULL,
    telefone bigint(11) NOT NULL,
    CONSTRAINT telefone_FK FOREIGN KEY (cpf) REFERENCES PROPRIETARIO (cpf)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS VEICULO (
    placa CHAR(7) NOT NULL,
    chassi VARCHAR(50) NOT NULL,
    corPredominante VARCHAR(10) NOT NULL,
    anoFabricacao INT(4) NOT NULL,
    codModelo INT(6) NOT NULL,
    cpf bigint(11) NOT NULL,
    codCategoria INT(2) NOT NULL,
    CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
    CONSTRAINT VEICULO_CHASSI_UK UNIQUE (chassi),
	CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf) REFERENCES PROPRIETARIO (cpf),
    CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (codModelo) REFERENCES MODELO (codModelo),
    CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codCategoria) REFERENCES CATEGORIA (codCategoria)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS LOCAL (
    codLocal INT(4) NOT NULL,
    latitude VARCHAR(10) NOT NULL,
    longitude VARCHAR(10) NOT NULL,
    velocidadePermitida INT(3) NOT NULL,
    CONSTRAINT LOCAL_PK PRIMARY KEY (codLocal)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS AGENTE (
    matricula INT(6) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    dtContratacao DATE NOT NULL,
    CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS TIPOINFRACAO (
    codTipoInfracao INT(3) NOT NULL,
    descInfracao VARCHAR(50) NOT NULL,
    valor DECIMAL(7,2) NOT NULL,
    CONSTRAINT TIPOINFRACAO_PK PRIMARY KEY (codTipoInfracao)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE TABLE IF NOT EXISTS INFRACAO (
	idInfracao INT(3) NOT NULL,
    dtHoraInfracao TIMESTAMP NOT NULL,
    velocidadeAferida INT(3),
    codTipoInfracao INT(3) NOT NULL,
    codLocal INT(4) NOT NULL,
    placa CHAR(7) NOT NULL,
    matricula INT(6) NOT NULL,
    CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
    CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa),
    CONSTRAINT INFRACAO_TIPOINFRACAO_FK FOREIGN KEY (codTipoInfracao) REFERENCES TIPOINFRACAO (codTipoInfracao),
    CONSTRAINT INFRACAO_LOCAL_FK FOREIGN KEY (codLocal) REFERENCES LOCAL (codLocal),
    CONSTRAINT INFRACAO_AGENTE_FK FOREIGN KEY (matricula) REFERENCES AGENTE (matricula)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;