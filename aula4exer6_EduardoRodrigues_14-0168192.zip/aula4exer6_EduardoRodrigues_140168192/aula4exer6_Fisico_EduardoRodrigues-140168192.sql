 /*
	Script de criação da estrutura da base dados aula4exer6. 
    Aluno: Eduardo Júnio Veloso Rodrigues
    Matrícula: 14/0168192
	Atividade: Aula 4 exercício 6 - Base de dados para controle de infrações.

*/


create database aula4Exer6;

use aula4Exer6;

CREATE TABLE VEICULO (
    placa varchar(7) not null,
    chassi varchar(17) not null,
    cor varchar(20) not null,
    codModelo int(6) not null,
    codCategoria int(2) not null,
    anoFabricacao int(4) not null,
    cpfProprietario int(11) not null,
	constraint VEICULO_PK primary key (placa)
);


CREATE TABLE MODELO (
    descricaoModelo varchar(100) not null,
    codModelo int(6)not null,
    constraint MODELO_PK primary key (codModelo)
);

CREATE TABLE PROPRIETARIO (
    cpf int(11) not null,
    nome varchar(30) not null,
    bairro varchar(30) not null,
    cidade varchar(30) not null,
    estado varchar(20) not null,
    sexo varchar(1) not null,
    dtaNascimento datetime not null,
    constraint PROPRIETARIO_PK primary key (cpf)
);

CREATE TABLE CATEGORIA (
    descricaoCategoria varchar(100) not null,
    codCategoria int(2) not null,
    constraint CATEGORIA_PK primary key (codCategoria)
);

CREATE TABLE TIPO_INFRACAO (
    codInfracao int not null,
    valor int(5) not null,
    descricaoInfracao varchar(100) not null,
	constraint TIPOINFRACAO_PK primary key (codInfracao)

);

CREATE TABLE LOCALIZACAO (
    codLocal int not null,
    latitude varchar(7) not null,
    longitude varchar(7) not null,
    velocidadePermitida int(3) not null,
	constraint LOCALIZACAO_PK primary key (codLocal)

);

CREATE TABLE AGENTE (
    dtaContratacao datetime not null,
    nome varchar(30) not null,
    matriculaAgente int(5) not null,
	constraint AGENTE_PK primary key (matriculaAgente)

);

CREATE TABLE INFRACAO (
    placa varchar(7) not null,
    dtaInfracao datetime not null,
    codInfracao int not null,
    matriculaAgente int not null,
    velocidadeAferida int(3),
    codLocal int not null,
    constraint INFRACAO_PK primary key (placa, dtaInfracao, codInfracao),
    constraint INFRACAO_VEICULO_FK foreign key (placa)  references VEICULO(placa),	
	constraint INFRACAO_TIPOINFRACAO_FK foreign key (codInfracao)  references TIPO_INFRACAO(codInfracao),
	constraint INFRACAO_AGENTE_FK foreign key (matriculaAgente)  references AGENTE(matriculaAgente),
	constraint INFRACAO_LOCAL_FK foreign key (codLocal)  references LOCALIZACAO(codLocal)
);


CREATE TABLE telefone (
    cpfProprietario int(11) not null,
    telefone int(10) not null,
	constraint TELEFONE_PK primary key (cpfProprietario),
	constraint TELEFONE_FK foreign key (cpfProprietario)  references PROPRIETARIO(cpf)

);

#drop database aula4Exer6;

show tables;
