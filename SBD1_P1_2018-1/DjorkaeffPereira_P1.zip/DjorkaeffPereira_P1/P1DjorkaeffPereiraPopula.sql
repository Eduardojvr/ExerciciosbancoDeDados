﻿-- Nome: Djorkaeff Alexandre Vilela Pereira
-- Matrícula: 16/0026822
-- Quantidade de tabelas: 4
-- Nome da base de dados: djorkaeffpereira
-- Descrição do projeto: controle de serviços Software House
-- Descrição do script: popula o banco de dados

USE djorkaeffpereira;

INSERT INTO EQUIPE (nomeFantasia, codInternacional, DDD, numeroTelefone)
VALUES
  ('Equipe da folha', 55, 61, 986110148),
  ('Uzumaki Team', 55, 62, 984065337);

INSERT INTO EMAIL (email, idEquipe)
VALUES
  ('djorkaeff@gmail.com', 1),
  ('dufrae@gmail.com', 1),
  ('izabella@gmail.com', 2);

INSERT INTO CONTRATO (dataEmissao, valorTotal)
VALUES
  ('2018-07-13', 50000),
  ('2015-05-12', 80000);

INSERT INTO SERVICO (descricao, precoUnitario, idContrato, idEquipe)
VALUES
  ('Criação de sistema de estoque', 5000, 100, 1),
  ('Treinamento de testes funcionais', 8000, 101, 2);