﻿-- Nome: Djorkaeff Alexandre Vilela Pereira
-- Matrícula: 16/0026822
-- Quantidade de tabelas: 4
-- Nome da base de dados: djorkaeffpereira
-- Descrição do projeto: controle de serviços Software House
-- Descrição do script: cria o banco de dados

CREATE DATABASE IF NOT EXISTS djorkaeffpereira;
USE djorkaeffpereira;

CREATE TABLE EQUIPE (
  idEquipe INT NOT NULL AUTO_INCREMENT,
  nomeFantasia VARCHAR(40) NOT NULL,
  codInternacional INT(2) NOT NULL,
  DDD INT(2) NOT NULL,
  numeroTelefone INT(9) NOT NULL,
  CONSTRAINT EQUIPE_PK PRIMARY KEY (idEquipe)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE EMAIL (
  email VARCHAR(40) NOT NULL,
  idEquipe INT NOT NULL,
  CONSTRAINT EMAIL_FK FOREIGN KEY (idEquipe) REFERENCES EQUIPE(idEquipe)
) ENGINE = InnoDB;

CREATE TABLE CONTRATO (
  idContrato INT NOT NULL AUTO_INCREMENT,
  dataEmissao DATE NOT NULL,
  valorTotal INT NOT NULL,
  CONSTRAINT CONTRATO_PK PRIMARY KEY (idContrato)
) ENGINE = InnoDB AUTO_INCREMENT = 100;

CREATE TABLE SERVICO (
  idServico INT NOT NULL AUTO_INCREMENT,
  descricao VARCHAR(40) NOT NULL,
  precoUnitario INT NOT NULL,
  idContrato INT NOT NULL,
  idEquipe INT NOT NULL,
  CONSTRAINT SERVICO_PK PRIMARY KEY (idServico),
  CONSTRAINT SERVICO_FK1 FOREIGN KEY (idContrato) REFERENCES CONTRATO(idContrato),
  CONSTRAINT SERVICO_FK2 FOREIGN KEY (idEquipe) REFERENCES EQUIPE(idEquipe)
) ENGINE = InnoDB AUTO_INCREMENT = 1;