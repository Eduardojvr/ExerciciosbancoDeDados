﻿-- Nome: Djorkaeff Alexandre Vilela Pereira
-- Matrícula: 16/0026822
-- Quantidade de tabelas: 4
-- Nome da base de dados: djorkaeffpereira
-- Descrição do projeto: controle de serviços Software House
-- Descrição do script: apaga o banco de dados

USE djorkaeffpereira;

DROP TABLE SERVICO;
DROP TABLE CONTRATO;
DROP TABLE EMAIL;
DROP TABLE EQUIPE;