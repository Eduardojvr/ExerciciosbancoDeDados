﻿--     Prova1 REMOCAO  --
-- SoftwareHouse --
-- 1 base de dados ---
-- 05 tabelas --


use prova1;

DROP TABLE GERACONTRATO;
DROP TABLE CONTRATO;
DROP TABLE SERVICO;
DROP TABLE EQUIPE;
DROP TABLE EMAIL;