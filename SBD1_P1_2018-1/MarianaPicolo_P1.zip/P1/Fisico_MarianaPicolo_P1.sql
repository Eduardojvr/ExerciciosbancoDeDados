﻿--     Prova1 FISICO   --
-- SoftwareHouse --
-- 1 base de dados ---
-- 05 tabelas --


create database if not exists prova1;

use prova1;

CREATE TABLE EMAIL (
email_PK int(4) NOT NULL AUTO_INCREMENT,
email varchar(25),
CONSTRAINT PRIMARY KEY (email_PK)
) Engine = InnoDB;

CREATE TABLE EQUIPE (
codigoEquipe varchar(5) NOT NULL,
telefone varchar(11) NOT NULL,
nomeFantasia varchar(50) NOT NULL,
email_FK int(4) NOT NULL,
CONSTRAINT PRIMARY KEY(codigoequipe),
CONSTRAINT FOREIGN KEY(email_FK) REFERENCES EMAIL(email_PK)
) Engine = InnoDB;


CREATE TABLE SERVICO (
idServico int(4) NOT NULL AUTO_INCREMENT,
descricao varchar(50) NOT NULL,
preco decimal(6,2) NOT NULL,
codigoEquipe_FK varchar(5) NOT NULL,
CONSTRAINT PRIMARY KEY(idServico),
CONSTRAINT FOREIGN KEY (codigoEquipe_FK) REFERENCES EQUIPE(codigoEquipe)
) Engine = InnoDB;


CREATE TABLE CONTRATO (
numero int(5) NOT NULL AUTO_INCREMENT,
dataEmissao datetime,
valorTotal decimal(6,2),
CONSTRAINT PRIMARY KEY(numero)
) Engine = InnoDB;


CREATE TABLE GERACONTRATO (
geracontrato_PK int(5) NOT NULL AUTO_INCREMENT,
numero int(5),
CONSTRAINT PRIMARY KEY(geracontrato_PK),
CONSTRAINT FOREIGN KEY(numero) REFERENCES CONTRATO(numero)
) Engine = InnoDB;




