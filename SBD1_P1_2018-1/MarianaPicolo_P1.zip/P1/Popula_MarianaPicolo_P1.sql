﻿--     Prova1 POPULA  --
-- SoftwareHouse --
-- 1 base de dados ---
-- 05 tabelas --

USE prova1;

INSERT INTO EMAIL(email) VALUES ('mariana@gmail.com');
INSERT INTO EMAIL(email) VALUES ('luciana@hotmail.com');

INSERT INTO EQUIPE(telefone, nomeFantasia, email_FK) VALUES ('5561978563248', 'Vendas Diretas', 1);
INSERT INTO EQUIPE(telefone, nomeFantasia, email_FK) VALUES ('5561987453658', 'Desenvolvimento Front-End', 2);

-- INSERT INTO () VALUES ();
-- INSERT INTO () VALUES ();

-- INSERT INTO () VALUES ();
-- INSERT INTO () VALUES ();
