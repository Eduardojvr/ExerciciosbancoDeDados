﻿-- Autor: Maria Luiza Ferreira
-- Matricula: 160014433
-- Nome do projeto: P1
-- Base de dados:
-- Quantidade de tabela:
-- DDL

CREATE DATABASE IF NOT EXISTS p1;
USE p1;

CREATE TABLE PRODUTO (
precoUnitario decimal(4,2),
nome varchar(50),
codigoProduto int(6),
CONSTRAINT PRODUTO_PK PRIMARY KEY(codigoProduto)
);

CREATE TABLE FUNCIONARIO (
cpf numeric(11),
nome varchar(50),
rua varchar(50),
bairro varchar(30),
numero int(4),
cep int(8),
cpfGerente numeric(11),
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY(cpf),
CONSTRAINT FUNCIONARIO_FUNCIONARIO_FK FOREIGN KEY(cpfGerente) REFERENCES FUNCIONARIO(cpf)
);

CREATE TABLE ITEM (
numeroSequencial int(4) AUTO_INCREMENT,
quantidadeTotal int(8),
precoTotal decimal(6,2),
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY(numeroSequencial)
)ENGINE= InnoDB  AUTO_INCREMENT=1;

CREATE TABLE telefone (
telefone numeric(13),
cpf numeric(11),
CONSTRAINT telefone_FUNCIONARIO_FK FOREIGN KEY(cpf) REFERENCES FUNCIONARIO(cpf)
);

CREATE TABLE VENDA (
cpf numeric(11),
codigoProduto int(6),
CONSTRAINT VENDA_FUNCIONARIO_FK FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf),
CONSTRAINT VENDA_PRODUTO_FK FOREIGN KEY(codigoProduto) REFERENCES PRODUTO (codigoProduto),
CONSTRAINT VENDA_PK PRIMARY KEY(cpf,codigoProduto)
);

CREATE TABLE NOTAFISCAL (
dataEmissao date,
numeroNota int(4),
valorTotal int(6),
cpf numeric(11),
codigoProduto int(6),
CONSTRAINT NOTAFISCAL_PK PRIMARY KEY(numeroNota),
CONSTRAINT NOTAFISCAL_VENDA_FK FOREIGN KEY(cpf, codigoProduto) REFERENCES VENDA(cpf, codigoProduto)
)ENGINE= InnoDB  AUTO_INCREMENT=1000;

CREATE TABLE registra (
numeroNota int(4),
numeroSequencial int(4),
CONSTRAINT registra_ITEM_FK FOREIGN KEY(numeroSequencial) REFERENCES ITEM (numeroSequencial),
CONSTRAINT registra_NOTAFISCAL_FK FOREIGN KEY(numeroNota) REFERENCES NOTAFISCAL(numeroNota)
);


CREATE TABLE formada (
cpf numeric(11),
codigoProduto int(6),
numeroItem int(4),
CONSTRAINT formada_VENDA_FK FOREIGN KEY(cpf, codigoProduto) REFERENCES VENDA (cpf, codigoProduto),
CONSTRAINT formada_ITEM_FK FOREIGN KEY(numeroItem) REFERENCES ITEM (numeroSequencial)
);

