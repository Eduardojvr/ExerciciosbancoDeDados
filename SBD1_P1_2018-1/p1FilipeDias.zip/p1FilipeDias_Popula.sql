﻿-- Autor: Filipe Dias
-- Banco de Dados: MySql
-- Banco de Dados(nome): p1fisico
-- SCRIPT POPULA (DML)
-- PROJETO => 01 base de dados / 5 tabelas

USE p1fisico;

INSERT INTO FUNCIONARIO VALUES (
  04590615185,
  'Filipe Dias Soares Lima',
  'Gama',
  'Qi 05',
  'Brasilia'
);

INSERT INTO FUNCIONARIO VALUES (
  57385920187
  'Kleber Nunes de Lima',
  'Gama',
  'Qi 05',
  'Brasilia'
);

INSERT INTO PRODUTO VALUES (
  null,
  04590615185,
  25,
  'Arroz Tio João'
);

INSERT INTO PRODUTO VALUES (
  null,
  57385920187,
  25,
  'Feijão Tio Jorge'
);

INSERT INTO REGISTRO VALUES (
  1542,
  25,
  1,
  2,
  50
);

INSERT INTO REGISTRO VALUES (
  1542,
  25,
  2,
  2,
  50
);


