﻿-- Autor: Filipe Dias
-- Banco de Dados: MySql
-- Banco de Dados(nome): p1fisico
-- SCRIPT APAGA (DDL)
-- PROJETO => 01 base de dados / 5 tabelas

USE p1fisico;

DROP TABLE telefone;
DROP TABLE nota;
DROP TABLE registro;
DROP TABLE produto;
DROP TABLE funcionario;