﻿-- Tipo de Escript: DDL
-- data: 11/05/2018
-- Nome do banco: felipechaves
-- Numero de Tabelas:4

CREATE DATABASE IF NOT EXISTS felipechaves
DEFAULT CHARSET utf8
DEFAULT COLLATE utf8_general_ci;

USE felipechaves;


CREATE TABLE CONTRATO(
  idContrato      INT           NOT NULL  AUTO_INCREMENT,
  valor           FLOAT(12,2)   NOT NULL,
  dataContrato    DATE          NOT NULL,
  CONSTRAINT CONTRATO_PK PRIMARY KEY(idContrato)
)ENGINE = Innodb DEFAULT CHARSET utf8 AUTO_INCREMENT = 100;

CREATE TABLE EQUIPE(
  idEquipe        INT         NOT NULL AUTO_INCREMENT,
  nome            VARCHAR(30) NOT NULL,
  numero          INT(9)      NOT NULL,
  ddd             INT(2)      NOT NULL,
  CONSTRAINT EQUIPE_PK PRIMARY KEY(idEquipe)
)ENGINE = Innodb DEFAULT CHARSET utf8 AUTO_INCREMENT =1;

CREATE TABLE emails(
  emails      VARCHAR(30)      NOT NULL,
  idEquipe   INT              NOT NULL,
  CONSTRAINT email_idequipe_fk FOREIGN KEY(idEquipe) REFERENCES EQUIPE(idEquipe)
)ENGINE = Innodb DEFAULT CHARSET utf8;

CREATE TABLE SERVICO(
  preco            FLOAT(12,2)         NOT NULL,
  descricao        VARCHAR(100)        NOT NULL,
  idContrato       INT                 NOT NULL,
  idEquipe         INT                 NOT NULL,
  CONSTRAINT SERVICO_IDCONTRATO FOREIGN KEY(idContrato) REFERENCES CONTRATO(idContrato),
  CONSTRAINT SERVICO_IDEQUIPE FOREIGN KEY(idEquipe) REFERENCES EQUIPE(idEquipe),
  CONSTRAINT SERVICO_PK PRIMARY KEY(idContrato, idEquipe)
)ENGINE = Innodb DEFAULT CHARSET utf8;