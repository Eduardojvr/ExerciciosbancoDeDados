﻿-- Tipo de Escript: DML
-- data: 11/05/2018
-- Nome do banco: felipechaves
-- Aluno: Felipe Borges de Souza Chaves

use felipechaves;

DROP TABLE SERVICO;
DROP TABLE emails;
DROP TABLE EQUIPE;
DROP TABLE CONTRATO;
