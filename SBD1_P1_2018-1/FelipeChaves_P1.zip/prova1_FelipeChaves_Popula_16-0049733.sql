﻿-- Tipo de Escript: DML
-- data: 11/05/2018
-- Nome do banco: felipechaves
-- Aluno: Felipe Borges de Souza Chaves

USE felipechaves;

INSERT INTO CONTRATO(valor, dataContrato) VALUES (1234.32, '2018-4-4'), (153512.52, '2018--3-2');

INSERT INTO EQUIPE(nome, numero, ddd) VALUES ('DreamTeam', 123123433, 22), ('Asfaulto', 983932432, 61);

INSERT INTO emails(idEquipe, emails) VALUES (1, 'olaeusougoku@gmail.com'), (2, 'asfaultebom@yahho.com');

INSERT INTO SERVICO(preco, descricao, idContrato, idEquipe) VALUES (234123.02, 'identificar asfaulto no google maps', 100, 2),
                                                                     (412343.02, 'Sonhar até o mundo acabar', 101,1);