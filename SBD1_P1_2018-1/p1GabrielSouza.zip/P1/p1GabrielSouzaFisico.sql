﻿-- nome do projeto: GabrielSouza
-- quantidade de tabelas: 7
-- nome da base: GabrielSouza
CREATE DATABASE IF NOT EXISTS GabrielSouza
DEFAULT CHARACTER SET utf8;
DEFAULT COLLATE utf8_general_ci;

USE GabrielSouza;

CREATE TABLE GERENTE (
mtGerente int(6)   NOT NULL,
cpf bigint(11)     NOT NULL,
nome varchar(30)   NOT NULL,
cidade varchar(20) NOT NULL,
bairro varchar(20) NOT NULL,
rua varchar(20)    NOT NULL,
cep int(8)         NOT NULL,
CONSTRAINT GERENTE_PK PRIMARY KEY (mtGerente)
)Engine = InnoDb DEFAULT CHARSET = utf8;

CREATE TABLE TELEFONE_GERENTE (
telefones int(9)   NOT NULL,
mtGerente int(6)   NOT NULL,
CONSTRAINT TELEFONE_GERENTE_FK FOREIGN KEY (mtGerente)REFERENCES GERENTE (mtGerente)
)Engine = InnoDb DEFAULT CHARSET = utf8;

CREATE TABLE FUNCIONARIO (
cpf bigint(11)       NOT NULL,
mtGerente int(6)     NOT NULL,
nome varchar(30)     NOT NULL,
cidade varchar(20)   NOT NULL,
bairro varchar(20)   NOT NULL,
rua varchar(20)      NOT NULL,
cep int(8)           NOT NULL,
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (cpf),
CONSTRAINT FUNCIONARIO_GERENTE_FK FOREIGN KEY(mtGerente) REFERENCES GERENTE (mtGerente)
)Engine = InnoDb DEFAULT CHARSET = utf8;

CREATE TABLE TELEFONE_FUNCIONARIO (
telefones int(9)   NOT NULL,
cpfFuncionario bigint(11)   NOT NULL,
CONSTRAINT TELEFONE_FUNCIONARIO_FK FOREIGN KEY (cpfFuncionario)REFERENCES FUNCIONARIO (cpf)
)Engine = InnoDb DEFAULT CHARSET = utf8;


CREATE TABLE PRODUTO (
cod int(6)                   NOT NULL,
precoUnitario decimal(5,2)   NOT NULL,
nome varchar(20)             NOT NULL,
CONSTRAINT PRODUTO_PK PRIMARY KEY (cod)
)Engine = InnoDb DEFAULT CHARSET = utf8;

CREATE TABLE VENDA (
idVenda int(6)             auto_increment,
cpfFuncionario bigint(11)  NOT NULL,
codProduto int(6)          NOT NULL,
CONSTRAINT VENDA_PK PRIMARY KEY (idVenda),
CONSTRAINT VENDA_FUNCIONARIO_FK FOREIGN KEY(cpfFuncionario) REFERENCES FUNCIONARIO (cpf),
CONSTRAINT VENDA_PRODUTO_FK FOREIGN KEY(codProduto) REFERENCES PRODUTO (cod)
)Engine = InnoDb DEFAULT CHARSET = utf8 AUTO_INCREMENT = 1;

CREATE TABLE NOTA_FISCAL (
idNota int(6)   auto_increment,
idVenda int(6)  NOT NULL,
dtEmissao date  NOT NULL,
CONSTRAINT NOTA_FISCAL_PK PRIMARY KEY (idNota),
CONSTRAINT NOTA_FISCAL_VENDA_FK FOREIGN KEY(idVenda) REFERENCES VENDA (idVenda)
)Engine = InnoDb DEFAULT CHARSET = utf8 AUTO_INCREMENT = 1000;