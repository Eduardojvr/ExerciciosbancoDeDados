﻿-- << P1 >>
--
-- Script de Criacao
--
-- Data de criacao     : 11/05/2018
-- Autor               : Joao Pedro Gomes Cabral
-- Base de Dados (nome): JoaoFerreira
-- Numero de tabelas: 05

CREATE DATABASE IF NOT EXISTS JoaoFerreira;
USE JoaoFerreira;


CREATE TABLE IF NOT EXISTS FUNCIONARIO(
cpf		varchar(11)	NOT NULL,
nomeCompleto		varchar(100)	NOT NULL,
bairro		varchar(20)	NOT NULL,
rua		varchar(20)	NOT NULL,
cep		varchar(11)	NOT NULL,
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (cpf)
);

CREATE TABLE IF NOT EXISTS TELEFONES(
telefone		varchar(12)	NOT NULL,
cpf_func	varchar(11)		NOT NULL,
CONSTRAINT TELEFONE_FK FOREIGN KEY (cpf_func) REFERENCES FUNCIONARIO (cpf)
);

CREATE TABLE IF NOT EXISTS PRODUTOS(
codigoUnicoProduto		INT		NOT NULL AUTO_INCREMENT,
nomeProduto		varchar(20)	NOT NULL,
precoUnitario		decimal(10,2)		NOT NULL,
cpf_func varchar(11) NOT NULL,
CONSTRAINT PRODUTOS_PK PRIMARY KEY (codigoUnicoProduto),
CONSTRAINT PRODUTOS_FK FOREIGN KEY (cpf_func) REFERENCES FUNCIONARIO (cpf)
)AUTO_INCREMENT = 1;



CREATE TABLE IF NOT EXISTS VENDA(
numeroVenda INT NOT NULL AUTO_INCREMENT,
codigoUnicoProduto		INT		NOT NULL,
quantidadeProduto		int	NOT NULL,
cpf_func varchar(11) NOT NULL,
CONSTRAINT VENDAS_FK FOREIGN KEY (cpf_func) REFERENCES FUNCIONARIO (cpf),
CONSTRAINT CODIGO_PRODUTOS_FK FOREIGN KEY (codigoUnicoProduto) REFERENCES PRODUTOS (codigoUnicoProduto),
CONSTRAINT VENDAS_PK PRIMARY KEY (numeroVenda)
)AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS NOTAFISCAL(
idNota INT NOT NULL AUTO_INCREMENT,
valorTotal		decimal(10,2)		NOT NULL,
dataEmissao		date	NOT NULL,
numeroVenda int NOT NULL,
CONSTRAINT NOTAFISCAL_FK FOREIGN KEY (numeroVenda) REFERENCES VENDA (numeroVenda),
CONSTRAINT NOTAFISCAL_PK PRIMARY KEY (idNota)
)AUTO_INCREMENT = 1;
