﻿-- << P1 >>
--
-- Script de APAGA
--
-- Data de criacao     : 11/05/2018
-- Autor               : Joao Pedro Gomes Cabral
-- Base de Dados (nome): JoaoFerreira
-- Numero de tabelas: 05

USE JoaoFerreira;

DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE PRODUTOS;
DROP TABLE TELEFONES;
DROP TABLE FUNCIONARIO;