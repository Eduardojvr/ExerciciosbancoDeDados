﻿-- << P1 >>
--
-- Script de POPULA
--
-- Data de criacao     : 11/05/2018
-- Autor               : Joao Pedro Gomes Cabral
-- Base de Dados (nome): JoaoFerreira
-- Numero de tabelas: 05

USE JoaoFerreira;


INSERT INTO FUNCIONARIO VALUES
('03231425166','Joao Ferreira','Sudoeste','ccsw2', '7065819'),
('03231425162','Pedro Ferreira','Cruzeiro','1109', '7082929');

INSERT INTO TELEFONES VALUES
('81900200','03231425166'),
('99617272','03231425162');

INSERT INTO PRODUTOS(nomeProduto, precoUnitario, cpf_func) VALUES
('Produto 1','100.2','03231425166'),
('Produto 2','200.5','03231425162');

INSERT INTO VENDA(codigoUnicoProduto, quantidadeProduto, cpf_func) VALUES
(1,2,'03231425166'),
(2,2,'03231425162');


INSERT INTO NOTAFISCAL(valorTotal, dataEmissao,numeroVenda) VALUES

('2000.5','2000-05-05',1),
('1000.5','2001-05-06',2);
