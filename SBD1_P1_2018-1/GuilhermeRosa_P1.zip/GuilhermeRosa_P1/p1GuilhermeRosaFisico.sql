﻿-- Script de Criação
-- Nome: Guilherme Marques Rosa
-- Matricula: 160007739
-- Base de dados: GuilhermeRosa
-- Projeto: 1 Base de Dados e 5 Tabelas

CREATE DATABASE IF NOT EXISTS GuilhermeRosa
DEFAULT CHARACTER SET utf8;

USE GuilhermeRosa;

CREATE TABLE SERVICO (
idServico int(4) NOT NULL AUTO_INCREMENT,
descricao varchar(30) NOT NULL,
valor decimal(7,2) NOT NULL,
CONSTRAINT SERVICO_pk PRIMARY KEY(idServico)
) ENGINE = innodb;

CREATE TABLE CONTRATO (
idContrato int(5) NOT NULL AUTO_INCREMENT,
dtEmissao date NOT NULL,
valorTotal decimal(8,2) NOT NULL,
CONSTRAINT CONTRATO_pk PRIMARY KEY(idContrato)
) ENGINE = innodb AUTO_INCREMENT = 100;

CREATE TABLE exige (
idContrato int(5) NOT NULL,
idServico int(4) NOT NULL,
CONSTRAINT exige_pk PRIMARY KEY(idContrato,idServico),
CONSTRAINT exige_CONTRATO_fk FOREIGN KEY(idContrato) REFERENCES CONTRATO (idContrato),
CONSTRAINT exige_SERVICO_fk FOREIGN KEY(idServico) REFERENCES SERVICO (idServico)
) ENGINE = innodb;

CREATE TABLE EQUIPE (
idEquipe int(4) NOT NULL AUTO_INCREMENT,
nomeEquipe varchar(30) NOT NULL,
foneLider bigint(13) NOT NULL,
idServico int(4) NOT NULL,
CONSTRAINT EQUIPE_pk PRIMARY KEY(idEquipe),
CONSTRAINT EQUIPE_SERVICO_fk FOREIGN KEY(idServico) REFERENCES SERVICO (idServico)
) ENGINE = innodb;

CREATE TABLE email (
email varchar(30) NOT NULL,
idEquipe int(4) NOT NULL,
CONSTRAINT email_EQUIPE_fk FOREIGN KEY(idEquipe) REFERENCES EQUIPE (idEquipe)
) ENGINE = innodb;

