﻿-- Script de Popula
-- Nome: Guilherme Marques Rosa
-- Matricula: 160007739
-- Base de dados: GuilhermeRosa
-- Projeto: 1 Base de Dados e 5 Tabelas

USE GuilhermeRosa;

INSERT INTO SERVICO VALUES
  (null,'Desenvolvimento Web', 1000.50),
  (null,'Manutenção de Código', 380.07);

INSERT INTO CONTRATO VALUES
  (null, '2018-03-03', 1000.50),
  (null, '2018-04-04', 380.07);

INSERT INTO exige VALUES
  (100,1),
  (101,2);

INSERT INTO EQUIPE VALUES
  (null,'coDestroyer',5561999008877,2),
  (null,'BestDev',5561988119900,1);

INSERT INTO email VALUES
  ('example@email.com',1),
  ('example2@email.com',2);