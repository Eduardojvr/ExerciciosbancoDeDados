﻿-- Script de Apaga
-- Nome: Guilherme Marques Rosa
-- Matricula: 160007739
-- Base de dados: GuilhermeRosa
-- Projeto: 1 Base de Dados e 5 Tabelas

USE GuilhermeRosa;

DROP TABLE email;
DROP TABLE EQUIPE;
DROP TABLE exige;
DROP TABLE SERVICO;
DROP TABLE CONTRATO;