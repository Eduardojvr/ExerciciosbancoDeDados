﻿-- < KamillaSouza> --
-- Banco de dados: MySQL
-- Nome Bnaco de Dados: KamillaSouza
-- Quantidade de Tabelas: 7
-- 1 Base de dados
-- ----------------------------------------------------

CREATE DATABASE IF NOT EXISTS KamillaSouza
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci;

USE KamillaSouza;

CREATE TABLE FUNCIONARIO (
  cpf             INTEGER(11) NOT NULL,
  nomeCompleto    varChar(35) NOT NULL,
  gerente         varChar(35) NOT NULL,
  numero          INTEGER(10) NOT NULL,
  rua             varChar(20) NOT NULL,
  bairro          varChar(20) NOT NULL,
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (cpf)
)ENGINE INNODB DEFAULT CHARSET = utf8;

CREATE TABLE PRODUTO (
  codProduto              INTEGER NOT NULL AUTO_INCREMENT,
  precoUnitarioProduto    INTEGER(10) NOT NULL,
  nomeProduto             varChar(35) NOT NULL,
CONSTRAINT PRODUTO_PK PRIMARY KEY (codProduto)
)ENGINE INNODB AUTO_INCREMENT = 10 DEFAULT CHARSET = utf8;

CREATE TABLE vende (
  cpf             INTEGER(11) NOT NULL,
  codProduto       INTEGER(10) NOT NULL,
CONSTRAINT FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
CONSTRAINT FOREIGN KEY(codProduto) REFERENCES PRODUTO (codProduto)
)ENGINE INNODB DEFAULT CHARSET = utf8;

CREATE TABLE TELEFONE (
  cpf             INTEGER(11) NOT NULL,
  telefone        INTEGER(9)  NOT NULL,
CONSTRAINT NOTA_FISCAL_FUNCIONARIO_FK FOREIGN KEY (cpf)
)ENGINE INNODB DEFAULT CHARSET = utf8;

CREATE TABLE NOTA_FISCAL (
  numeroNota             INTEGER NOT NULL AUTO_INCREMENT,
  dataEmissao            date NOT NULL,
  valorTotal             INTEGER(20) NOT NULL,
  cpf                    INTEGER(11) NOT NULL,
CONSTRAINT NOTA_FISCAL_PK PRIMARY KEY (numeroNota),
CONSTRAINT NOTA_FISCAL_FUNCIONARIO_FK FOREIGN KEY (cpf)
)ENGINE INNODB AUTO_INCREMENT = 1000 DEFAULT CHARSET = utf8;

CREATE TABLE ITEN (
  numeroVenda             INTEGER NOT NULL AUTO_INCREMENT,
  identProduto            date NOT NULL,
  quantProduto            INTEGER(50) NOT NULL,
  precoUnitario           INTEGER(20) NOT NULL,
  precoTotalIten          INTEGER(20) NOT NULL,
CONSTRAINT NOTA_FISCAL_PK PRIMARY KEY (numeroNota),
)ENGINE INNODB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE possui (
  numeroVenda             INTEGER(10) NOT NULL,
  numeroNota              INTEGER(10)  NOT NULL
CONSTRAINT possui_ITEN_FK FOREIGN KEY (cpf)
CONSTRAINT possui_NOTA_FISCAL_FK FOREIGN KEY (cpf)
)ENGINE INNODB DEFAULT CHARSET = utf8;