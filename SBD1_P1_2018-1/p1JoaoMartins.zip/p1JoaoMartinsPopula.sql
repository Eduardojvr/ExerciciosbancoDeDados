﻿-- Tipo de script: DDL (criação)
-- Nome do projeto: JoaoMartins
-- Nome da base de dados: JoaoMartins
-- Quantidade de tabelas: 4

use JoaoMartins;

insert into FUNCIONARIO values
(123, 'Joao', 'Asa norte', 'L2', 213, 6199619333),
(321, 'Maria', 'Asa sul', 'L2', 213, 6199616666);

insert into PRODUTO values
(1111, 50.9, 'Calca jeans'),
(1235, 100.0, 'Calca social');

insert into VENDA (quantidadeProduto, precoTotal, codigoProduto, cpf) values
(1, 50.9, 1111, 123),
(2, 200.0, 1235, 321);

insert into NOTAFISCAL (dataEmissao, numeroSequencial, valorTotal) values
('2018-05-06', 1, 50.9),
('2017-07-06', 2, 200.0);