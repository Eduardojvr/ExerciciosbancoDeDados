﻿-- Tipo de script: DDL (criação)
-- Nome do projeto:JoaoMartins
-- Nome da base de dados: JoaoMartins
-- Quantidade de tabelas: 4
--
create database if not exists JoaoMartins;

use JoaoMartins;

CREATE TABLE FUNCIONARIO (
  cpf bigint NOT NULL,
  nome varchar(30) not null,
  bairro varchar(30) not null,
  rua varchar(30) not null,
  numero int,
  telefone numeric(11),
  constraint FUNCIONARIO_PK PRIMARY KEY (cpf)
)Engine = InnoDB;

CREATE TABLE PRODUTO (
  codigoProduto bigint not null,
  preco decimal(7, 2) not null,
  nome varchar(30) not null,
  constraint PRODUTO_PK PRIMARY KEY (codigoProduto)
)Engine = InnoDB;

CREATE TABLE VENDA (
  numeroSequencial int AUTO_INCREMENT,
  quantidadeProduto int,
  precoTotal decimal(8, 2),
  codigoProduto bigint,
  cpf bigint,
  constraint VENDA_PK PRIMARY KEY (numeroSequencial),
  constraint VENDA_PRODUTO_FK FOREIGN KEY(codigoProduto) REFERENCES PRODUTO (codigoProduto),
  constraint VENDA_FUNCIONARIO_FK FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
)Engine = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE NOTAFISCAL (
  idNota bigint AUTO_INCREMENT,
  dataEmissao date,
  numeroSequencial int,
  valorTotal decimal(8, 2),
  constraint NOTAFISCAL_PK PRIMARY KEY (idNota),
  constraint NOTAFISCAL_VENDA_FK FOREIGN KEY (numeroSequencial) REFERENCES VENDA (numeroSequencial)
)Engine = InnoDB AUTO_INCREMENT = 1000;