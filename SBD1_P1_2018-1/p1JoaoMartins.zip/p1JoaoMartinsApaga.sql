﻿-- Tipo de script: DDL (criação)
-- Nome do projeto:JoaoMartins
-- Nome da base de dados: JoaoMartins
-- Quantidade de tabelas: 4

USE JoaoMartins;

DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE FUNCIONARIO;