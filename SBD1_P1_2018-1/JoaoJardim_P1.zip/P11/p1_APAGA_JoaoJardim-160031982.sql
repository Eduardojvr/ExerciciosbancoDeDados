﻿-- ----------------------- < JoaoJardim > ---------------------------
--              Nome do banco de dados: JoaoJardim
--              Quantidade de Bancos: 01
--              Quantidade de tabelas: 05

DROP TABLE VENDA;
DROP TABLE CONTRATO;
DROP TABLE SERVICO;
DROP TABLE EMAIL;
DROP TABLE EQUIPE;