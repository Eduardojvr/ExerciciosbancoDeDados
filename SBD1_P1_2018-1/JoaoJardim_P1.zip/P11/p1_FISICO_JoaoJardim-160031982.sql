﻿-- ----------------------- < JoaoJardim > ---------------------------
--              Nome do banco de dados: JoaoJardim
--              Quantidade de Bancos: 01
--              Quantidade de tabelas: 05

create database JoaoJardim;

use JoaoJardim;

create TABLE EQUIPE(
  idEquipe          int NOT NULL AUTO_INCREMENT,
  nomeFantasia      varchar(50) NOT NULL,
  cdInternacional   int(2) NOT NULL,
  ddd               int(2) NOT NULL,
  numero            int(9) NOT NULL,
  CONSTRAINT EQUIPE_PK PRIMARY KEY(idEquipe)
)ENGINE innoDB;

create TABLE EMAIL(
  idEquipe          int NOT NULL,
  email             varchar(50) NOT NULL,
  CONSTRAINT EMAILS_EQUIPE_FK FOREING KEY(idEquipe) REFERENCES EQUIPE(idEquipe)
)ENGINE innoDB;

create TABLE SERVICO(
  idServico          int NOT NULL AUTO_INCREMENT,
  descricao          varchar(100) NOT NULL,
  precoUnitario      decimal(8,2) NOT NULL,
  CONSTRAINT SERVICO_PK PRIMARY KEY(idServico)
)ENGINE innoDB;

create TABLE CONTRATO(
  idContrato         int NOT NULL AUTO_INCREMENT,
  valorTotal         decimal(8,2) NOT NULL,
  dtEmissao          date NOT NULL,
  CONSTRAINT SERVICO_PK PRIMARY KEY(idServico)
)ENGINE innoDB;

create TABLE VENDA(
  idContrato         int NOT NULL,
  idServico          int NOT NULL,
  idEquipe           int NOT NULL,
  sequencial         int NOT NULL AUTO_INCREMENT,
  CONSTRAINT VENDA_CONTRATO_FK FOREING KEY(idContrato) REFERENCES CONTRATO(idContrato),
  CONSTRAINT VENDA_SERVICO_FK FOREING KEY(idServico) REFERENCES SERVICO(idServico),
  CONSTRAINT VENDA_EQUIPE_FK FOREING KEY(idEquipe) REFERENCES EQUIPE(idEquipe)
)ENGINE innoDB;







