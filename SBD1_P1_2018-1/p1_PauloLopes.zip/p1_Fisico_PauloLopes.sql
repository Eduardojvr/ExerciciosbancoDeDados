﻿-- --------------------------------- --
-- --           PROVA 1           -- --
-- --           CRIACAO           -- --
-- Paulo Victor de Menezes Lopes     --
-- 160016428                         --
-- Banco de Dados: bdP1PauloVictor   --
--                                   --
-- Geração de Modelo físico          --
-- Sql ANSI 2003 - brModelo.         --
-- --------------------------------- --

CREATE DATABASE IF NOT EXISTS bdP1PauloVictor;
USE bdP1PauloVictor;

CREATE TABLE PRODUTO (
idProduto BigInt AUTO_INCREMENT,
nome Varchar(100),
precoUnitario Float,

CONSTRAINT PRODUTO_PK PRIMARY KEY (idProduto)
)ENGINE InnoDB AUTO_INCREMENT = 1;

CREATE TABLE FUNCIONARIO (
cpf BigInt(11),
nome Varchar(100),

CONSTRAINT FUNCIONARIO_PK PRIMARY KEY (cpf)
)ENGINE InnoDB;

CREATE TABLE telefone (
funcionario BigInt(11),
telefone BigInt(13),
FOREIGN KEY(funcionario) REFERENCES FUNCIONARIO (cpf)
)ENGINE InnoDB;

CREATE TABLE endereco (
funcionario BigInt(11),
bairro Varchar(50),
rua Varchar(50),
cidade Varchar(50),
numero Int,
FOREIGN KEY(funcionario) REFERENCES FUNCIONARIO (cpf)
)ENGINE InnoDB;

CREATE TABLE NOTAFISCAL (
idNotaFiscal BigInt PRIMARY KEY AUTO_INCREMENT,
dtEmissao Date,
valorTotal Float
)ENGINE InnoDB AUTO_INCREMENT = 1000;

CREATE TABLE VENDA (
cpf BigInt(11),
idNotaFiscal BigInt,
idProduto BigInt,
quantidade Int,

FOREIGN KEY(idNotaFiscal) REFERENCES NOTAFISCAL (idNotaFiscal),
FOREIGN KEY(idProduto) REFERENCES PRODUTO (idProduto),
FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
)ENGINE InnoDB;
