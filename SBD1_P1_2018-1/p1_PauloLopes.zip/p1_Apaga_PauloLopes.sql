﻿-- --------------------------------- --
-- --           PROVA 1           -- --
-- --            APAGA            -- --
-- Paulo Victor de Menezes Lopes     --
-- 160016428                         --
-- Banco de Dados: bdP1PauloVictor   --
--                                   --
-- Geração de Modelo físico          --
-- Sql ANSI 2003 - brModelo.         --
-- --------------------------------- --

USE bdP1PauloVictor;

DROP TABLE venda;
DROP TABLE notaFiscal;
DROP TABLE produto;
DROP TABLE telefone;
DROP TABLE endereco;
DROP TABLE funcionario;
