﻿-- --------------------------------- --
-- --           PROVA 1           -- --
-- --           INSERE            -- --
-- Paulo Victor de Menezes Lopes     --
-- 160016428                         --
-- Banco de Dados: bdP1PauloVictor   --
--                                   --
-- Geração de Modelo físico          --
-- Sql ANSI 2003 - brModelo.         --
-- --------------------------------- --

USE bdP1PauloVictor;

INSERT INTO produto (nome, precoUnitario) VALUES
("carrinho", "5.00"),
("boneco Spider-man", "29.90");

INSERT INTO funcionario VALUES
("02006666142", "Paulo Victor Lopes"),
("12345678912", "Pedro Augusto");

INSERT INTO telefone VALUES
("02006666142", "556199966924"),
("12345678912", "556199988889");

INSERT INTO endereco VALUES
("02006666142", "Taguatingo Norte", "Vicente Pires", "12", "12"),
("12345678912", "Gama", "Gama Leste", "32", "54");

INSERT INTO notaFiscal (dtEmissao, valorTotal) VALUES
("2018/05/28", "29,90"),
("2018/09/21", "34,90");

INSERT INTO venda VALUES
("02006666142", "2", "1"),
("12345678912", "1", "1"),
("12345678912", "2", "1");
