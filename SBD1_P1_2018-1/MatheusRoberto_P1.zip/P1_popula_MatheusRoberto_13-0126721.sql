﻿-- Nome Projeto: P1
-- Nome database: softwareHouse
-- Nome Autor: Matheus Roberto
-- Projeto: 4 tuplas

use softwareHouse;

insert into SERVICO(descricao, precoUnitario) VALUES
  ("SERVICO é bastante bacana", 199948);

insert into EQUIPE(nomeFantasia, telefone) VALUES
  ("FANTASIA", "2398401824923");

insert into CONTRATO(dataEmissao, valorTotal) VALUES
  (1999-02-02, 3241241234);

insert into email(email) VALUES
  ("roberto.matheus@bol.com.br");
