﻿-- Nome Projeto: P1
-- Nome database: softwareHouse
-- Nome Autor: Matheus Roberto
-- Projeto: 1 tupla

use sotwareHouse;

drop table CONTRATO;
drop table SERVICO;
drop table EQUIPE;
drop table email;
drop table ATIVIDADE;

