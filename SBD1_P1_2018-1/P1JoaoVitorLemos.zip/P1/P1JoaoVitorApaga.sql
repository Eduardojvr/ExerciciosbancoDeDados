/*
Autor: João Vítor Morandi Lemos
Matricula: 160010195
nome da base de dados: Prova1
projeto do qual pertence: P1
tabelas: 06
*/

use Prova1;

drop table venda;
drop table item;
drop table nota_fiscal;
drop table produto;
drop table gerente;
drop table funcionario;