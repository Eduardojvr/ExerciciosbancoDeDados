/*
Autor: João Vítor Morandi Lemos
Matricula: 160010195
nome da base de dados: Prova1
projeto do qual pertence: P1
tabelas: 06
*/

create database if not exists Prova1;

use Prova1;

create table produto(
	codigo int,
    nome varchar(20),
    preco int,
    constraint PRODUTO_PK primary key(codigo)
)Engine = InnoDB;

create table funcionario(
	cpf int,
    nome_completo varchar(40),
    endereco varchar(20),
    gerente varchar(40),
    telefone int,
	constraint FUNCIONARIO_PK primary key(cpf)
)Engine = InnoDB;

create table gerente(
	cpf int,
    nome_completo varchar(40),
    endereco varchar(20),
    telefone int,
    cpfFunc int,
	constraint GERENTE_PK primary key(cpf),
    constraint GERENTE_FUNCIONARIO_FK foreign key(cpfFunc) references funcionario(cpf)
)Engine = InnoDB;

create table nota_fiscal(
	numero int,
    data date,
	valor int,
    constraint NOTA_FISCAL_PK primary key(numero)
)Engine = InnoDB;

create table item(
	codigo_item int,
    preco_tot int,
    preco_int int,
    qtde_produto int,
    cod_produto int,
    numero_nota int,
    constraint ITEM_PK primary key(codigo_item),
    constraint ITEM_NOTA_FISCAL_FK foreign key(numero_nota) references nota_fiscal(numero)
)Engine = InnoDB;

create table venda(
	cpf int,
	numero int,
    constraint VENDA_FUNCIONARIO_FK foreign key(cpf) references funcionario(cpf),
    constraint VENDA_NOTA_FISCAL_FK foreign key(numero) references nota_fiscal(numero)
)Engine = InnoDB;
	