﻿-- PROJETO: p1GustavoSabino
-- numero de tabelas: 7
-- base de dados: gustavosabino

USE gustavosabino;

INSERT INTO FUNCIONARIO  VALUES (123,'Joao Junior','qnn 01 conjunto j casa 28')
INSERT INTO FUNCIONARIO  VALUES (321,'Beto Carreiro', 'qnn 01 conjunto j casa 29')
INSERT INTO FUNCIONARIO  VALUES (234,'Beto Carreiro junior', 'qnn 01 conjunto j casa 30')



INSERT INTO PRODUTO (precoUnitario, nome) VALUES (100,'roda')
INSERT INTO PRODUTO (precoUnitario, nome) VALUES (101,'pneu')


INSERT INTO telefone (telefone, cpf) VALUES (333444,321)
INSERT INTO telefone (telefone, cpf) VALUES (111222,123)


INSERT INTO acompanha (cpfSupervisor, cpf) VALUES (321,123)
INSERT INTO acompanha (cpfSupervisor, cpf) VALUES (321,234)

INSERT INTO VENDA (cpf,codigoUnico) VALUES (234,101)
INSERT INTO VENDA (cpf,codigoUnico) VALUES (234,100)


INSERT INTO NOTAFISCAL (dtEmissao,valorTotal,idVenda) VALUES ('22-01-2018',100)
INSERT INTO NOTAFISCAL (dtEmissao,valorTotal,idVenda) VALUES ('22-01-2018',101)

INSERT INTO notaProdutos (idNota, idVenda) VALUES (1,1)
INSERT INTO notaProdutos (idNota, idVenda) VALUES (1,2)