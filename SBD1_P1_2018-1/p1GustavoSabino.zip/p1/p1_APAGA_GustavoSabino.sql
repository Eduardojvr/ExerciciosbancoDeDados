﻿-- PROJETO: p1GustavoSabino
-- numero de tabelas: 7
-- base de dados: gustavosabino

USE gustavosabino;

DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE acompanha;
DROP TABLE telefone;
DROP TABLE PRODUTO;
DROP TABLE FUNCIONARIO;
DROP TABLE notaProdutos;