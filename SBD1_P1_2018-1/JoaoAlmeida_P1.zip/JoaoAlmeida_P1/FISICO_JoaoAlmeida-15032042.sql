﻿create database joaoalmeida;
use joaoalmeida;

DROP TABLE IF EXISTS `joaoalmeida`.`contrato`;
CREATE TABLE  `joaoalmeida`.`contrato` (
  `numero` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `valorTotal` decimal(10,0) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `joaoalmeida`.`servico`;
CREATE TABLE  `joaoalmeida`.`servico` (
  `codServico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `precoUnitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`codServico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `joaoalmeida`.`equipetrabalho`;
CREATE TABLE  `joaoalmeida`.`equipetrabalho` (
  `codequipeTrabalho` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nomeFantasia` varchar(100) NOT NULL,
  `telefone` decimal(9,0) NOT NULL,
  `ddd` decimal(2,0) NOT NULL,
  `codInternacional` decimal(2,0) NOT NULL,
  PRIMARY KEY (`codequipeTrabalho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `joaoalmeida`.`emailscontato`;
CREATE TABLE  `joaoalmeida`.`emailscontato` (
  `emailsContato_PK` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(80) NOT NULL,
  PRIMARY KEY (`emailsContato_PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;