USE p1;
CREATE TABLE  `p1`.`contrato` (
  `idContrato` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `valorTotal` int(20) unsigned NOT NULL,
  PRIMARY KEY (`idContrato`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
CREATE TABLE  `p1`.`servico` (
  `idServico` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `precoUnitario` int(10) unsigned NOT NULL,
  `descricao` varchar(100) NOT NULL,
  PRIMARY KEY (`idServico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1;
CREATE TABLE  `p1`.`equipe` (
  `idEquipe` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(20) NOT NULL,
  `nomeEquipe` varchar(20) NOT NULL,
  `telefone` varchar(13) NOT NULL,
  PRIMARY KEY (`idEquipe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;