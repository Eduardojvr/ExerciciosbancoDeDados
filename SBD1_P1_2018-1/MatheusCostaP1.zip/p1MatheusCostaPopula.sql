USE p1;
INSERT INTO p1.contrato VALUES (1,110);
INSERT INTO p1.contrato VALUES (2,220);
INSERT INTO p1.servico VALUES (1,220, 'descricao1');
INSERT INTO p1.servico VALUES (2,110,'descricao2');
INSERT INTO p1.equipe VALUES (1,'equipe1@gmail.com','equipe1','1111111111111');
INSERT INTO p1.equipe VALUES (2,'equipe2@gmail.com','equipe2','2222222222222');