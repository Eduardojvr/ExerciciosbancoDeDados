USE p1;
DROP TABLE IF EXISTS `p1`.`contrato`;
DROP TABLE IF EXISTS `p1`.`equipe`;
DROP TABLE IF EXISTS `p1`.`servico`;