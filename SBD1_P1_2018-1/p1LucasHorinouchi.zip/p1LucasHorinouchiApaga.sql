﻿-- Aluno: Lucas Hiroshi Horinouchi
--
-- Script Apaga
--
-- Numero de tabelas: 5
--
-- Banco de Dados: MySQL
--
-- Nome Banco: bdMagazine
-- Nome Projeto: bdMagazine
--
--

USE bdMagazine;

DROP TABLE VENDA;
DROP TABLE TELEFONES;
DROP TABLE NOTA_FISCAL;
DROP TABLE EMPREGADO;
DROP TABLE PRODUTO;