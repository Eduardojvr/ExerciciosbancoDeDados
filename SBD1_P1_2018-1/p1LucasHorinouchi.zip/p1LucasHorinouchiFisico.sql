﻿-- Aluno: Lucas Hiroshi Horinouchi
--
-- Script Criacao
--
-- Numero de tabelas: 5
--
-- Banco de Dados: MySQL
--
-- Nome Banco: bdMagazine
-- Nome Projeto: bdMagazine
--
--

CREATE DATABASE IF NOT EXISTS bdMagazine
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci;


USE bdMagazine;

CREATE TABLE PRODUTO (
  precoUnitario decimal(8,2) NOT NULL,
  nomeProduto varchar(50)    NOT NULL,
  codigoProduto int          NOT NULL,
  PRIMARY KEY(codigoProduto)
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE EMPREGADO (
  cpf bigint(11)               NOT NULL,
  nomeEmpregado varchar(50)    NOT NULL,
  rua varchar(50)              NOT NULL,
  bairro varchar(50)           NOT NULL,
  numero int                   NOT NULL,
  gerenteCpf bigint(11)        NOT NULL,
  CONSTRAINT EMPREGADO_PK PRIMARY KEY(cpf)
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE NOTA_FISCAL (
  idNotaFiscal bigint AUTO_INCREMENT,
  dataEmissao datetime,
  CONSTRAINT NOTA_FISCAL_PK PRIMARY KEY (idNotaFiscal)
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8 AUTO_INCREMENT=1000;

CREATE TABLE TELEFONES (
  telefones bigint(11),
  cpf bigint(11),
  CONSTRAINT TELEFONE_EMPREGADO_FK FOREIGN KEY(cpf) REFERENCES EMPREGADO(cpf)
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE VENDA (
  codigoProduto int,
  cpf bigint(11),
  qtdAdquirida int,
  numeroItem int,
  idNotaFiscal bigint,
  CONSTRAINT VENDA_PRODUTO_FK FOREIGN KEY(codigoProduto) REFERENCES PRODUTO (codigoProduto),
  CONSTRAINT VENDA_NOTA_FISCAL_FK FOREIGN KEY(idNotaFiscal) REFERENCES NOTA_FISCAL(idNotaFiscal),
  CONSTRAINT VENDA_EMPREGADO_FK FOREIGN KEY(cpf) REFERENCES EMPREGADO (cpf)
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;