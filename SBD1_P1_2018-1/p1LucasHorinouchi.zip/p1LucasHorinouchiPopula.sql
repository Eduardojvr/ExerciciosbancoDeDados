﻿-- Aluno: Lucas Hiroshi Horinouchi
--
-- Script Popula
--
-- Numero de tabelas: 5
--
-- Banco de Dados: MySQL
--
-- Nome Banco: bdMagazine
-- Nome Projeto: bdMagazine
--
--

USE bdMagazine;

INSERT INTO PRODUTO VALUES
(100.00, 'carteira', 123),
(99.99, 'Calca Jean', 12);

INSERT INTO EMPREGADO VALUES
(06425874195, 'Joao Carlos', 'Palmeiras','Centro',12,06425874195),
(12378951478, 'Henrique Carlos', 'Palmeiras','Industrial',11,06425874195);

/*
ALTER TABLE EMPREGADO FOREIGN KEY
CONSTRAINT EMPREGADO_EMPREGADO_FK FOREIGN KEY(cpf) REFERENCES EMPREGADO(gerenteCpf);
*/

INSERT INTO NOTA_FISCAL VALUES
(NULL, '2017-7-7'),
(NULL, '2018-8-7');

INSERT INTO TELEFONES VALUES
(14785236978, 06425874195),
(78965478521, 06425874195);

INSERT INTO VENDA VALUES
(123, 06425874195,12, 1, 1000),
(12, 06425874195,1, 1, 1001);