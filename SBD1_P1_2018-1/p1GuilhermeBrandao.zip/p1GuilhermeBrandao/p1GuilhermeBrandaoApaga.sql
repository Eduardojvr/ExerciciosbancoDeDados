﻿-- Nome: Guilherme Siqueira Brandão --
-- Matrícula: 16/0007763 --
-- Tabelas: 06 tabelas --
-- Base de Dados: bdMagazine --

DROP TABLE GERENCIA;
DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE TELEFONES;
DROP TABLE FUNCIONARIO;