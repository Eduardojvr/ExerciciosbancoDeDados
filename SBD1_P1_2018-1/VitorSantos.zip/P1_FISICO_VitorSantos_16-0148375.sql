﻿-- tipo: MySql
-- quantidade de tabelas: 3 tabelas
-- nome da base de dados: VitorSantos

CREATE DATABASE IF NOT EXISTS VitorSantos;

use VitorSantos;

CREATE TABLE SERVICO_EQUIPE (
idServico int(6) AUTO_INCREMENT NOT NULL,
preco int(7) NOT NULL,
descricao varchar(100) NOT NULL,
idContrato int(6),
codEquipe int(7) NOT NULL,
nomeEquipe varchar(100) NOT NULL,
telefoneLider bigint(13) NOT NULL,
CONSTRAINT SERVICO_EQUIPE_PK PRIMARY KEY(idServico,codEquipe)
) Engine = InnoDb AUTO_INCREMENT=1;

CREATE TABLE CONTRATO (
idContrato int(6) AUTO_INCREMENT,
valorContrato int(8) NOT NULL,
dataEmissao date NOT NULL,
CONSTRAINT CONTRATO_PK PRIMARY KEY(idContrato)
) Engine = InnoDb AUTO_INCREMENT=1;

CREATE TABLE EMAIL(
emailEquipe varchar(100) NOT NULL,
idServico int(6),
codEquipe int(7),
CONSTRAINT EMAIL_SERVICO_EQUIPE_FK FOREIGN KEY(codEquipe,idServico) REFERENCES SERVICO_EQUIPE (idServico,codEquipe)
) Engine = InnoDb;

ALTER TABLE SERVICO_EQUIPE ADD FOREIGN KEY(idContrato) REFERENCES CONTRATO (idContrato);
