﻿-- tipo: MySql
-- quantidade de tabelas: 3 tabelas
-- nome da base de dados: VitorSantos
USE VitorSantos;

DROP TABLE EMAIL;
DROP TABLE CONTRATO;
DROP TABLE SERVICO_EQUIPE;