﻿-- tipo: MySql
-- quantidade de tabelas: 3 tabelas
-- nome da base de dados: VitorSantos

USE vitorSantos;

INSERT SERVICO_EQUIPE(idServico,preco,descricao,idContrato,codEquipe,nomeEquipe,telefoneLider) VALUES (1,2584,'servico 1',1,1234,'fga',556134354141), (2,2645,'servico 2', 2, 1456,'unb',556133845454);
INSERT CONTRATO (idContrato,valorContrato,dataEmissao) VALUES (1,2584,'2015/05/04'), (2,2645,'2016/06/06');
INSERT EMAIL(emailEquipe,idServico,codEquipe) VALUES ('equipe1@gmail.com',1,1234), ('equipe2@gmail.com',2,1456);