﻿-- SCRIPT DE REMOÇÃO (DDL)
-- Base de dados: MySQL
-- Data 11/05/2018
-- Nome da base de dados: WilliamAlmeida
-- 1 Base de dados
-- 6 tabelas

USE WilliamAlmeida;

DROP TABLE POSSUI;
DROP TABLE SVCONTRATADO;
DROP TABLE CONTRATO;
DROP TABLE EMAIL;
DROP TABLE EQUIPE;
DROP TABLE SVCOMERCIALIZADO;