﻿-- SCRIPT DE CRIAÇÃO (DDL)
-- Base de dados: MySQL
-- Data 11/05/2018
-- Nome da base de dados: WilliamAlmeida
-- 1 Base de dados
-- 6 tabelas

CREATE DATABASE IF NOT EXISTS WilliamAlmeida
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci;

USE WilliamAlmeida;

CREATE TABLE SVCOMERCIALIZADO(
  idComercializado int(4) NOT NULL AUTO_INCREMENT,
  descricao varchar(30) NOT NULL,
  precoUnitario decimal(9,2) NOT NULL,
CONSTRAINT SVCOMERCIALIZADO_FK PRIMARY KEY (idComercializado)
)ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;


CREATE TABLE EQUIPE (
  idEquipe int(4) NOT NULL AUTO_INCREMENT,
  nomeEquipe varchar(30) NOT NULL,
  cdInternacional int(2) NOT NULL,
  DDD int(2) NOT NULL,
  numero int(9) NOT NULL,
CONSTRAINT SVCOMERCIALIZADO_FK PRIMARY KEY (idEquipe)
)ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE EMAIL (
  email varchar(30) NOT NULL,
  idEquipe int(4) NOT NULL,
CONSTRAINT EMAIL_EQUIPE_FK FOREIGN KEY (idEquipe) REFERENCES EQUIPE(idEquipe)
)ENGINE = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE CONTRATO (
  numeroContrato int(4) NOT NULL AUTO_INCREMENT,
  dataContrato date NOT NULL,
CONSTRAINT CONTRATO_PK PRIMARY KEY (numeroContrato)
)ENGINE = InnoDB AUTO_INCREMENT = 100 DEFAULT CHARSET = utf8;

CREATE TABLE SVCONTRATADO (
  nrSvContratado int(4) NOT NULL AUTO_INCREMENT,
  valorEquipe decimal(9,2) NOT NULL,
  numeroContrato int(4) NOT NULL,
  idEquipe int(4) NOT NULL,
CONSTRAINT SVCONTRATADO_PK PRIMARY KEY (nrSvContratado),
CONSTRAINT SVCONTRATADO_EQUIPE_FK FOREIGN KEY (idEquipe) REFERENCES EQUIPE(idEquipe),
CONSTRAINT SVCONTRATADO_CONTRATO_FK FOREIGN KEY (numeroContrato) REFERENCES CONTRATO(numeroContrato)
)ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE possui (
  nrSvContratado int(4) NOT NULL,
  idComercializado int(4) NOT NULL,
CONSTRAINT possui_SVCONTRATADO_FK FOREIGN KEY (nrSvContratado) REFERENCES SVCONTRATADO(nrSvContratado),
CONSTRAINT possui_SVCOMERCIALIZADO_FK FOREIGN KEY (idComercializado) REFERENCES SVCOMERCIALIZADO(idComercializado)
)ENGINE = InnoDB;