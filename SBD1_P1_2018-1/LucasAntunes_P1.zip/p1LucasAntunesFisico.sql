﻿-- nome projeto: LucasAntunes
-- nome base de dados? MySQL
-- nº de bases de dados: 1
-- nº de tabelas: 3
-- SCRIPT DE CRIACAO (DLL)

CREATE DATABASE IF NOT EXISTS LucasAntunes
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci;

USE LucasAntunes;

CREATE TABLE IF NOT EXISTS CONTRATO (
idContrato   int(5)         NOT NULL AUTO_INCREMENT,
dtEmissao     date          NOT NULL,
valorContrato decimal(11,2) NOT NULL,
constraint CONTRATO_PK PRIMARY KEY(idContrato)
)ENGINE = InnoDB AUTO_INCREMENT = 100 DEFAULT CHARSET = utf8;

CREATE TABLE IF NOT EXISTS EQUIPE (
idGrupo   int(5)       NOT NULL AUTO_INCREMENT,
nome      varchar(50)  NOT NULL,
email     varchar(20)  NOT NULL,
telefone  bigint(13)      NOT NULL,
CONSTRAINT EQUIPE_PK PRIMARY KEY(idGrupo)
)ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8;

CREATE TABLE IF NOT EXISTS SERVICO (
idServico     int(5)       NOT NULL AUTO_INCREMENT,
precoUnitario decimal(6,2) NOT NULL,
descricao     varchar(50)  NOT NULL,
idGrupo       int(5)       NOT NULL,
idContrato   int(5)       NOT NULL,
CONSTRAINT SERVICO_PK PRIMARY KEY(idServico),
CONSTRAINT SERVICO_EQUIPE_FK FOREIGN KEY(idGrupo) REFERENCES EQUIPE (idGrupo),
CONSTRAINT SERVICO_CONTRATO_FK FOREIGN KEY(idContrato) REFERENCES CONTRATO (idContrato)
)ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8

