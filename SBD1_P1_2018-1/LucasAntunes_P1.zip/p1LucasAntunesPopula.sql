﻿-- nome projeto: LucasPenido
-- nome base de dados: MySQL
-- nº de bases de dados: 1
-- nº de tabelas: 3
-- SCRIPT DE INSERCAO (DML)

USE LucasPenido;

INSERT INTO CONTRATO VALUES
(null, '2018/05/11', 1423184.20),
(null, '2018/03/20', 1814723.30);

INSERT INTO EQUIPE VALUES
(null, 'FGA_Software', 'contFGASO@gmail.com', 5561994371234),
(null, 'FGA_Espacial', 'contFGAES@gmail.com', 5561978142394);

INSER INTO SERVICO VALUES
(null, 1000, 'Servico de software', 1, 100),
(null, 2000, 'Servico de Espacial', 2, 101);