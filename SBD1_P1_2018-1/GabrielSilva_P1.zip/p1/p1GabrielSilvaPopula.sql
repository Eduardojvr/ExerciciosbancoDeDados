﻿-- AUTOR: GABRIEL BATISTA ALBINO SILVA - 160028361
-- NOME DO PROJETO: SOFTWARE HOUSE
-- SCRIPT POPULA (DML)
-- 1 DATABASE
-- 6 TABELAS

use gabrielsilva;

insert into EQUIPE (nomeEquipe) VALUES
  ('Calangos'),
  ('Orcs'),
  ('Jaguatiricas');

insert into telefoneLider VALUES
  (55, 61, 996969696, 1),
  (55, 62, 998989898, 2),
  (55, 62, 997979797, 3);

insert into emails  values
  ('albino@gmail.com', 1),
  ('htona@outlook.com', 2),
  ('rafissilva@gmail.com', 3),
  ('rafael@gmail.com', 1),
  ('clarisses@gmail.com', 2),
  ('thiagobbb@gmail.com', 3);

insert into servico (descricao, precoUnitario, idEquipe) VALUES
  ('Criação design', 1350.00, 1),
  ('Manutenção SBD', 950.00, 2),
  ('Manutenção Geral', 2560.00, 3);

insert into CONTRATO (precoTotal, dataEmissao) VALUES
  (2300.00, '2018-10-10'),
  (3910.00, '2017-03-03'),
  (950.00, '2016-09-09');

insert into contrato_servico VALUES
  (100, 1),
  (100, 2),
  (101, 3),
  (101, 1),
  (102, 2);