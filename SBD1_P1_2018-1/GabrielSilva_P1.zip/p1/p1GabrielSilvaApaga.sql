﻿-- AUTOR: GABRIEL BATISTA ALBINO SILVA - 160028361
-- NOME DO PROJETO: SOFTWARE HOUSE
-- SCRIPT APAGA (DDL)
-- 1 DATABASE
-- 6 TABELAS

use gabrielsilva;

drop table contrato_servico;
drop table contrato;
drop table servico;
drop table emails;
drop table telefonelider;
drop table equipe;