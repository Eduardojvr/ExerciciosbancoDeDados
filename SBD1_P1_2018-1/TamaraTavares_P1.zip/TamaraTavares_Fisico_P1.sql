﻿-- Quantidade de tabelas 5
-- projeto p1
-- nome da base de dados P1_SoftwareHouse

CREATE DATABASE P1_SoftwareHouse;
USE DATABASE P1_SoftwareHouse;


CREATE TABLE EQUIPE (
  idEquipe INT,
  nomeFantasia VARCHAR(20),
  codigoInter INT(2),
  ddd INT(2),
  numeroTel INT(9),
  CONSTRAINT idEquipe_PK PRIMARY KEY(idEquipe) REFERENCES EQUIPE (idEquipe)
);

CREATE TABLE SERVICO (
  idServico INT PRIMARY KEY,
  descricao VARCHAR(20),
  precoUnitario DOUBLE,
  idEquipe INT,
  CONSTRAINT idEquipe_FK FOREIGN KEY(idEquipe) REFERENCES EQUIPE (idEquipe)
);

CREATE TABLE CONTRATO (
  idContrato INT PRIMARY KEY,
  dataEmissao DATE,
  valorTotal DOUBLE,
  CONSTRAINT idContrato_PK PRIMARY KEY(idContrato) REFERENCES CONTRATO (idContrato)
);

CREATE TABLE emails (
  emails VARCHAR(20)
);

CREATE TABLE possui (
  sequencialServico INT,
  idServico INT,
  idContrato INT,
  CONSTRAINT idServico_FK FOREIGN KEY(idServico) REFERENCES SERVICO (idServico),
  CONSTRAINT idContrato_FK FOREIGN KEY(idContrato) REFERENCES CONTRATO (idContrato)
);

