﻿-- Quantidade de tabelas 5
-- projeto p1
-- nome da base de dados P1_SoftwareHouse

USE DATABASE P1_SoftwareHouse;

DROP TABLE EQUIPE;

DROP TABLE SERVICO;

DROP TABLE CONTRATO;

DROP TABLE emails;

DROP TABLE possui;

