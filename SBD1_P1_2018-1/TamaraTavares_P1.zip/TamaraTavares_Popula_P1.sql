﻿-- Quantidade de tabelas 5
-- projeto p1
-- nome da base de dados P1_SoftwareHouse

USE DATABASE P1_SoftwareHouse;

INSERT INTO EQUIPE("1","Alpha","55","61,99621310");
INSERT INTO EQUIPE("2","Beta","55","61","99621311");

INSERT INTO SERVICO("1","hospedagem","125.50","1");
INSERT INTO SERVICO("2","segurança","100","2");

INSERT INTO CONTRATO("1","11-05-2018","500");
INSERT INTO CONTRATO("2","11-05-2018","600");

INSERT INTO emails("aluno@unb.br");
INSERT INTO emails("grupo@unb.br");

INSERT INTO possui("1","1","1");
INSERT INTO possui("2","2","2");

