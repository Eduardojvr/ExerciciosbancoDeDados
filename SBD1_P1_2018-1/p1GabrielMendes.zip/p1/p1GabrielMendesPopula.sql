﻿-- Nome: Gabriel Braga Mendes --
-- Matricula: 150126077       --
-- Projeto p1                 --
-- 05 tabelas                 --
-- ------------------------   --

USE p1;

INSERT INTO PRODUTO(nomeProduto, precoUnitario) VALUES ('Sabao','15.00'),
                                                       ('Escova','10.00');

INSERT INTO FUNCIONARIO VALUES(12131313091,'Carlos','12',5,'Guara 1',70212424),
                              (42425656098,'Eduardo','10',3,'Guara 2',70212300);

INSERT INTO TELEFONE VALUES(61991918282,12131313091),
                           (61982828484,42425656098);

INSERT INTO VENDA(idProduto,cpf) VALUES(1,12131313091),
                                       (2,42425656098);

INSERT INTO NOTAFISCAL(1000,1,'2018-11-15','20.00',3,'2.00',10.00),
                      (1001,2,'2018-10-12','30.00',4,'3.00',20.00);