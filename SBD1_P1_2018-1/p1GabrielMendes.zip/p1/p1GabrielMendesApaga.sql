﻿-- Nome: Gabriel Braga Mendes --
-- Matricula: 150126077       --
-- Projeto p1                 --
-- 05 tabelas                 --
-- ------------------------   --

USE p1;

drop table NOTAFISCAL;
drop table VENDA;
drop table TELEFONE;
drop table FUNCIONARIO;
drop table PRODUTO;