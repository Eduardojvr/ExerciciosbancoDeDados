﻿-- Nome: Gabriel Braga Mendes --
-- Matricula: 150126077       --
-- Projeto p1                 --
-- 05 tabelas                 --
-- ------------------------   --

CREATE DATABASE IF NOT EXISTS p1 ;

USE p1;

CREATE TABLE IF NOT EXISTS PRODUTO (
idProduto int(8) not null AUTO_INCREMENT,
nomeProduto varchar(50) not null,
precoUnitario varchar(50) not null,
CONSTRAINT PRODUTO_PK PRIMARY KEY(idProduto)
)Engine = innodb AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS FUNCIONARIO (
cpf bigint(11) not null,
nomeFuncionario varchar(50) not null,
rua varchar(50) not null,
numero int(4) not null,
bairro varchar(50) not null,
cep int(8) not null,
CONSTRAINT FUNCIONARIO_PK PRIMARY KEY(cpf)
)Engine = innodb;

CREATE TABLE IF NOT EXISTS TELEFONE (
telefone bigint(12) not null,
cpf bigint(11) not null,
CONSTRAINT FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
)Engine = innodb;

CREATE TABLE IF NOT EXISTS VENDA (
idVenda int(8) not null AUTO_INCREMENT,
idProduto int(8) not null,
cpf bigint(11) not null,
CONSTRAINT VENDA_PK PRIMARY KEY(idVenda),
CONSTRAINT VENDA_PRODUTO_FK FOREIGN KEY(idProduto) REFERENCES PRODUTO (idProduto),
CONSTRAINT VENDA_FUNCIONARIO_FK FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
)Engine = innodb AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS NOTAFISCAL (
idNota int(8) not null AUTO_INCREMENT ,
idVenda int(8) not null,
dtEmissao date not null,
valorTotal decimal(8,2) not null,
qtProduto int(8) not null,
precoUnitario decimal(8,2) not null,
precoTotalItem decimal(8,2) not null,
CONSTRAINT NOTAFISCAL_PK PRIMARY KEY(idNota),
CONSTRAINT NOTAFISCAL_VENDA_FK FOREIGN KEY(idVenda) REFERENCES VENDA(idVenda)
)Engine = innodb AUTO_INCREMENT = 1000;
