﻿-- BASE DE DADOS dbLoja
-- Script Popula
-- 6 tabelas, 1 base de dados

USE dbLoja;

INSERT INTO enderecoFuncionario VALUES ('Aguas Claras', 'Norte', 'Brasilia', null),
                                       ('Samambaia', 'Sul', 'Brasilia', null);

INSERT INTO FUNCIONARIO VALUES ('05478796322', 'Joao Guerra', 00001, null),
                               ('12547896320', 'Marcos da Silva', 00002, null);

INSERT INTO telefone VALUES ('61985858587', '05478796322'),
                            ('61985855587', '12547896320');

INSERT INTO PRODUTO VALUES ('1234567', '5.00', 'Sabao'),
                            ('1234557', '10.00', 'Shampoo');






