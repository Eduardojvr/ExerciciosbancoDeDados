﻿-- BASE DE DADOS dbLoja
-- Script Apaga
-- 6 tabelas, 1 base de dados

USE dbLoja;

DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE telefone;
DROP TABLE FUNCIONARIO;
DROP TABLE enderecoFuncionario;




