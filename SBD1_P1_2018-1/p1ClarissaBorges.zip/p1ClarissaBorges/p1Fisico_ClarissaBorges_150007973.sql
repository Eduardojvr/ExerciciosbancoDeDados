﻿-- BASE DE DADOS dbLoja
-- Script Fisico
-- 6 tabelas, 1 base de dados

CREATE DATABASE IF NOT EXISTS dbLoja;

USE dbLoja;

CREATE TABLE IF NOT EXISTS enderecoFuncionario (
cidade varchar(20) NOT NULL,
bairro varchar(20) NOT NULL,
estado varchar(20) NOT NULL,
idEndereco int(5) NOT NULL AUTO_INCREMENT,
CONSTRAINT idEndereco_PK PRIMARY KEY (idEndereco)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS FUNCIONARIO (
cpf varchar(11) NOT NULL,
nomeFuncionario varchar(50) NOT NULL,
enderecoResidencial int(5) NOT NULL,
acompanhaFuncionario varchar(11),
CONSTRAINT funcionario_PK PRIMARY KEY(cpf),
CONSTRAINT endereco_FK FOREIGN KEY (enderecoResidencial) REFERENCES enderecoFuncionario (idEndereco)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS telefone (
telefone varchar(12) NOT NULL,
cpfFuncionario varchar(11) NOT NULL,
CONSTRAINT funcionario_FK FOREIGN KEY (cpfFuncionario) REFERENCES FUNCIONARIO(cpf)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS PRODUTO (
codigoProduto int(7) NOT NULL PRIMARY KEY,
precoUnitario decimal(5,2) NOT NULL,
nomeProduto varchar(30) NOT NULL
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS VENDA (
codigoVenda int(7) NOT NULL AUTO_INCREMENT,
codigoProduto int(7) NOT NULL,
quantidadeProduto int(3) NOT NULL,
cpfVendedor varchar(11) NOT NULL,
CONSTRAINT codigoProduto_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO(codigoProduto),
CONSTRAINT codigoVenda_PF PRIMARY KEY (codigoVenda),
CONSTRAINT cpfVendedor_FK FOREIGN KEY (cpfVendedor) REFERENCES FUNCIONARIO (cpf)
) ENGINE = InnoDB AUTO_INCREMENT = 1000;

CREATE TABLE IF NOT EXISTS NOTAFISCAL (
codigoVenda int(7) NOT NULL,
codigoNota int(7) NOT NULL AUTO_INCREMENT,
dataEmissao date NOT NULL,
valorTotal decimal(6,2) NOT NULL,
CONSTRAINT codigoNota_PK PRIMARY KEY(codigoNota),
CONSTRAINT codigoVenda_FK FOREIGN KEY (codigoVenda) REFERENCES VENDA (codigoVenda)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

