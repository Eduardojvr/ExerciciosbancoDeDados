﻿-- Prova1
-- 06 Tabelas
-- prova1
-- DDL

create database if not exists prova1;

USE prova1;

CREATE TABLE FUNCIONARIO (
  cpf bigint,
  nomeCompleto varchar(100),
  bairro varchar(50),
  cidade varchar(50),
  numero bigint,
  PRIMARY KEY(cpf)
) Engine = InnoDB;

CREATE TABLE PRODUTO (
  precoUnitario decimal(7,2),
  nome varchar(20),
  codigo bigint AUTO_INCREMENT,
  PRIMARY KEY(codigo)
)Engine = InnoDB;

CREATE TABLE ITEM_PRODUTO (
  precoTotal decimal(10, 2),
  seqVenda bigint,
  precoUnitario decimal(7, 2),
  qtde int,
  codigoItem bigint ,
  PRIMARY KEY(seqVenda,codigo)
)

CREATE TABLE telefone (
  telefone bigint,
  cpf bigint,
  FOREIGN KEY (cpf) references FUNCIONARIO(cpf)
)Engine = InnoDB;

CREATE TABLE VENDA (
  codigo bigint AUTO_INCREMENT,
  cpf bigint,
  notaFiscal bigint,
  FOREIGN KEY(codigo) REFERENCES PRODUTO (codigo),
  FOREIGN KEY(cpf) REFERENCES FUNCIONARIO (cpf)
)Engine = InnoDB;

CREATE TABLE NOTA_FISCAL (
  codigo bigint PRIMARY KEY,
  data date,
  valorToral decimal(10, 2)
)

