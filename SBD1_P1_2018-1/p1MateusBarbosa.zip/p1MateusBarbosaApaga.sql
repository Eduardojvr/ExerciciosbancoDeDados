﻿-- 6 tabelas.
-- Projeto Prova1
-- Script de Exclusao
-- Base: MateusBarbosa
use MateusBarbosa;

DROP TABLE telefones;
DROP TABLE NOTAFISCAL;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE FUNCIONARIO;
DROP TABLE GERENTE;