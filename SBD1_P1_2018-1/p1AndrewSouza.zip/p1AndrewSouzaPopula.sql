﻿-- Andrew Lucas Guedes de Souza - 160023921 - 11/05/2018
-- Projeto: P1 SBD
-- Nome da Base de Dados: AndrewSouza
-- Numero de tabelas: 5

USE AndrewSouza;

-- notas fiscais
INSERT INTO NOTAFISCAL VALUES (1000, 50.20, '2018-05-11' ), (1001, 31.00, '2018-04-05');

-- produtos
INSERT INTO PRODUTO VALUES (12345, 15.50, "Cadeira"), (34344, 50.20, "Jarro de flores");

-- funcionarios
INSERT INTO FUNCIONARIO VALUES (04744105670, "NARUTO UZUMAKI", 04744105670, "Casa 32, Quadra 5, Vila da Folha");
INSERT INTO FUNCIONARIO VALUES (76754105647, "MORANGINHO DE SOUSA", 04744105670, "Apt 305, Quadra 3, Vila das Frutas");

-- telefones
INSERT INTO telefone VALUES (61924487634, 04744105670), (61844427684, 76754105647);

-- Vendas
INSERT INTO VENDA VALUES (1, 04744105670, 34344, 1000), (2, 76754105647, 12345, 1001);
