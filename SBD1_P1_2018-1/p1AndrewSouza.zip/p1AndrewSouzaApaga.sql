﻿-- Andrew Lucas Guedes de Souza - 160023921 - 11/05/2018
-- Projeto: P1 SBD
-- Nome da Base de Dados: AndrewSouza
-- Numero de tabelas: 5

USE AndrewSouza;

DROP TABLE VENDA;
DROP TABLE telefone;
DROP TABLE PRODUTO;
DROP TABLE FUNCIONARIO;
DROP TABLE NOTAFISCAL;