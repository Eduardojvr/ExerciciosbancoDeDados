﻿-- Isaac Borges Mota 11/0121996 11/05/2018
-- Prova p1
-- SCRIPT DDL DE REMOCAO
-- Banco de Dados: MySQL
--
-- Projeto
--      Base: 1
--   Tabelas: 5

USE isaacmota;

DROP TABLE VENDA;
DROP TABLE prestaCONTRATO;
DROP TABLE SERVICO;
DROP TABLE email;
DROP TABLE EQUIPE;