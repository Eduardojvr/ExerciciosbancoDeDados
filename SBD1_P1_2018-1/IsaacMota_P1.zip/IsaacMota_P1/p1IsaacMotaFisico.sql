﻿-- Isaac Borges Mota 11/0121996 11/05/2018
-- Prova p1
-- SCRIPT DDL DE CRIACAO
-- Banco de Dados: MySQL
--
-- Projeto
--      Base: 1
--   Tabelas: 5



CREATE DATABASE IF NOT EXISTS isaacmota
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci;

USE isaacmota;

CREATE TABLE EQUIPE (

  idEquipe integer NOT NULL AUTO_INCREMENT,
  nomeEquipe varchar(50) NOT NULL,
  telefone numeric(13) NOT NULL,

  CONSTRAINT EQUIPE_PK primary key (idEquipe)

)Engine = InnoDB AUTO_INCREMENT = 1000 CHARSET = utf8;

CREATE TABLE email (

  email varchar(30) NOT NULL,
  idEquipe integer NOT NULL,

  CONSTRAINT EMAILEQUIPE_FK FOREIGN KEY(idEquipe) REFERENCES EQUIPE (idEquipe)

)Engine = InnoDB CHARSET = utf8;


CREATE TABLE SERVICO (

  idServico integer NOT NULL AUTO_INCREMENT,
  descricao varchar(50) NOT NULL,
  precoUnitario double NOT NULL,

  CONSTRAINT SERVICO_PK primary key (idServico)

)Engine = InnoDB AUTO_INCREMENT = 1 CHARSET = utf8;

CREATE TABLE prestaCONTRATO (

  idServico integer NOT NULL,
  idEquipe integer NOT NULL,
  idContrato integer NOT NULL AUTO_INCREMENT,
  dataEmissao date NOT NULL,
  valorTotal double NOT NULL,

  CONSTRAINT prestaCONTRATO_PK PRIMARY KEY (idContrato),
  CONSTRAINT prestaCONTRATO_SERVICO_FK FOREIGN KEY(idServico) REFERENCES SERVICO (idServico),
  CONSTRAINT prestaCONTRATO_EQUIPE_FK FOREIGN KEY(idEquipe) REFERENCES EQUIPE (idEquipe)

)Engine = InnoDB AUTO_INCREMENT = 100 CHARSET = utf8;


CREATE TABLE VENDA (

  idVenda integer NOT NULL AUTO_INCREMENT,
  precoVenda double NOT NULL,
  idContrato integer NOT NULL,

  CONSTRAINT VENDA_PK PRIMARY KEY (idVenda),
  CONSTRAINT VENDA_CONTRATO_FK FOREIGN KEY (idContrato) REFERENCES prestaCONTRATO (idContrato)

)Engine = InnoDB AUTO_INCREMENT = 5000 CHARSET = utf8;

