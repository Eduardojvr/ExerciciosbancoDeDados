/*
	Script de criação da estrutura da base dados aula4exer5Evolucao3. 
    Aluno: Eduardo Júnio Veloso Rodrigues
    Matrícula: 14/0168192
	Atividade: Aula 4 exercício 5 Evolução 3
    
    Foi necessário reorganizar a ordem dos comando de criação
    das tabelas, pois no caso de chaves estrangeiras, a tabela a ser referenciada deve ser criada antes da
    tabela que fará referência.
    Foi necessário mover o atributo "idReceita" da tabela RECEITA para a primeira posição da constraint de
    chave primária "RECEITA_FK".
	Todas as alterações citadas acima também foram feitas nos níveis anteriores ao lógico.

*/


create database aula4exer5Evolucao3;

use aula4exer5Evolucao3;

create table ESPECIALIDADE (
	nomeEspecialidade varchar(30) not null,
    codEspecialidade int not null,
    constraint ESPECIALIDADE_PK primary key (codEspecialidade)
    
);

create table MEDICO(
	crm int(8) not  null,
    nome varchar(30) not null,
    constraint MEDICO_PK	primary key (crm)
);

create table PACIENTE(
	cpf bigint(11) not null,
    nome varchar(30) not null,
    idade int(3) not null,
    sexo varchar(1) not null,
    cidade varchar(30) not null,
    bairro varchar(30) not null,
    estado varchar(20) not null,
    cep bigint(10) not null,
    complemento varchar(100),
    constraint PACIENTE_PK primary key(cpf)
);

create table telefone(
	cpf bigint(11) not null,
    telefone bigint,
    constraint TELEFONE_PACIENTE_FK foreign key(cpf) references PACIENTE (cpf)
);

create table possui(
	crm int(8) not null,
    codEspecialidade int not null,
    constraint ESPECIALIDADE_FK foreign key (codEspecialidade) references ESPECIALIDADE(codEspecialidade)
);

create table CONSULTA(
	data datetime not null,
    cpf bigint(11) not null,
    crm int(8) not null,
    constraint CONSULTA_PK primary key(data, cpf, crm),
    constraint CONSULTA_MEDICO_FK foreign key (crm) references MEDICO(crm),
    constraint CONSULTA_PACIENTE_FK foreign key(cpf) references PACIENTE(cpf)
);

create table RECEITA(
	posologia varchar(100) not null,
    data datetime not null,
    cpf bigint(11) not null,
    crm int(8) not null,
    idReceita int not null,
    constraint RECEITA_PK primary key (idReceita, data, cpf, crm),
    constraint RECEITA_CONSULTA_FK foreign key (data, cpf, crm) references CONSULTA(data, cpf, crm)
);

create table MEDICAMENTO(
	descricao varchar(100) not null,
    codMedicamento int not null,
    nome varchar(30) not null,
    constraint MEDICAMENTO_PK primary key (codMedicamento)
);

create table contem(
	idReceita int  not null,
	codMedicamento int not null,
	constraint RECEITA_FK foreign key (idReceita) references RECEITA (idReceita),
    constraint MEDICAMENTO_FK foreign key (codMedicamento) references MEDICAMENTO (codMedicamento)
);

show tables;

#drop database aula4exer5Evolucao3;
