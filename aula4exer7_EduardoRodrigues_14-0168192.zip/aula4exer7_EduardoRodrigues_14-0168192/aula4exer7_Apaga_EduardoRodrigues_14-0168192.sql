-- --------     << aula4exer7 >>     ------------
-- 
--                    SCRIPT DE DEFINICAO (DDL)
-- 
-- Data Criacao ...........: 02/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 01/06/2019
--   => Exclusão de tabelas da base de dados
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
-- 
-- -----------------------------------------------------------------
use aula4exer7;

DROP TABLE localizacao;
DROP TABLE TRABALHA;
DROP TABLE PROJETO;
ALTER TABLE EMPREGADO DROP foreign key empregado_departamento_fk;
DROP TABLE DEPENDENTE;
DROP TABLE DEPARTAMENTO;
DROP TABLE EMPREGADO;
DROP TABLE TIPODEPENDENCIA;



