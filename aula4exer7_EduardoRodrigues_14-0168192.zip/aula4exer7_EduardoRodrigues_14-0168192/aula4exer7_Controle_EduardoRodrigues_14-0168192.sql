-- --------     << aula4exer7 >>     ------------
-- 
--                    SCRIPT DE CONTROLE
-- 
-- Data Criacao ...........: 01/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 01/06/2019
--   => Definição de privilégios ao usuário
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
-- 
-- -----------------------------------------------------------------

create user 'usufui' identified by 'fui123';

grant	select, 
		delete,
        update,
        insert
ON aula4exer7.*
TO 'usufui';

SHOW GRANTS FOR 'usufui'; -- Lista as permissões do usuário usufui

-- DROP USER 'usufui';
