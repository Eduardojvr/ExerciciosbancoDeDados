-- --------     << aula4exer7 >>     ------------
-- 
--                    SCRIPT DE MANIPULACAO (DML)
-- 
-- Data Criacao ...........: 02/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 01/06/2019
--   => Inserção de registros
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
-- 
-- -----------------------------------------------------------------
use aula4exer7;

insert into  EMPREGADO 
values 	(1000, null, null, 'Superviso Pedro', 'Rua principal', 8, 'Bairro São Pedro', 1000.22, 'M', '1970-08-12' ), -- supervisor
		(1001, null, null, 'Supervisora Ana', 'Rua Secundaria', 22, 'Bairro Veredas', 2356.22, 'F', '1955-02-19' ), -- supervisor
		(1002, null, null, 'João Guilherme', 'Rua do bairro', 12, 'Bairro jardins', '500.00','M', '1980-03-13' ), -- gerente
        (1003, null, null, 'Aurelio', 'Rua 521', 2, 'Bairro sul', '2432.00','M', '1984-07-14' ), -- gerente
		(1004, 1001, null, 'Guilherme', 'Rua 22', 56, 'Bairro Nobre', '600.00','M', '1983-04-18' ), -- empregado
        (1005, 1000, null, 'Maria', 'Rua 30', 74, 'Bairro Alameda', '700.00','F', '1980-03-13' ); -- empregado

insert into  DEPARTAMENTO 
values 	(1, 1002, 'Departamento de banco de dados', '2002-02-21'),
		(2, 1003, 'Departamento Desenvolvimento', '2002-02-21');
        
update EMPREGADO set codDepartamento=1 where (matricula=1000);
update EMPREGADO set codDepartamento=2 where (matricula=1001);
update EMPREGADO set codDepartamento=1 where (matricula=1002);
update EMPREGADO set codDepartamento=2 where (matricula=1003);
update EMPREGADO set codDepartamento=1 where (matricula=1004);
update EMPREGADO set codDepartamento=2 where (matricula=1005);
        
insert into  TIPODEPENDENCIA 
values 	(1, 'Filho' ),
		(2, 'Esposa'),
		(3, 'Irmão');
        
insert into  DEPENDENTE 
values 	(1, 1, 1000 ,'Maria','2000-12-01', 'F'),
		(2, 2, 1002 ,'Ana','1982-02-12', 'F'),
		(3, 3, 1001 ,'Pedro', '1960-03-21', 'M');

insert into  PROJETO 
values 	(1, 2, 'DevApp', 'Sala 12'),
		(2, 1, 'SGB youSql', 'Sala 13'),
		(3, 2, 'Game app', 'Sala 76');
	
insert into  TRABALHA 
values 	(1,1005, 30),
		(2,1004, 48),
		(3, 1001, 48);
        
insert into  localizacao 
values 	(1, 'Sala 23'),
		(1, 'Sala 24'),
        (2, 'Sala 01'),
        (2, 'Sala 08');
        
        
	

