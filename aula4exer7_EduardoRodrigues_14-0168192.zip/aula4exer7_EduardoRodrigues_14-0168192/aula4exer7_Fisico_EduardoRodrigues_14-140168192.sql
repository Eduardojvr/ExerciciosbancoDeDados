-- --------     << aula4exer7 >>     ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 01/06/2019
-- Autor(es) ..............: Eduardo Júnio Veloso Rodrigues
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula4exer7
-- 
-- Data Ultima Alteracao ..: 01/06/2019
--   => Criacao de tabelas
-- 
-- PROJETO => 01 Base de Dados
--         => 07 Tabelas
-- 
-- -----------------------------------------------------------------

create database if not exists aula4exer7;
use aula4exer7;

CREATE TABLE EMPREGADO (
    matricula bigint(11) not null auto_increment,
    matriculaSupervisor bigint(11),
    codDepartamento int(9),
    nome varchar(30) not null,
    rua varchar(30) not null,
    numero int(9) not null,
    bairro varchar(30) not null,
    salario decimal(6,2) not null,
    sexo enum('M','F') not null,
    dtNasc date not null,
    constraint empregado_pk PRIMARY KEY (matricula),
    constraint empregado_supervisor_fk foreign key (matriculaSupervisor) references EMPREGADO(matricula) 
)engine=InnoDB auto_increment=1000;

CREATE TABLE DEPARTAMENTO (
    codDepartamento int(9) not null auto_increment,
    matriculaGerente bigint(11),
    nome varchar(30) not null,
    dtInicio date not null,
    constraint departamento_pk PRIMARY KEY (codDepartamento),
	constraint departamento_empregado_fk foreign key (matriculaGerente) references EMPREGADO(matricula),
    constraint departamento_gerente_uk unique (matriculaGerente)
)engine=InnoDB auto_increment=1;

-- chave estrangeira de departamento em empregado
alter table EMPREGADO 
ADD constraint empregado_departamento_fk 
foreign key (codDepartamento) references DEPARTAMENTO(codDepartamento);

CREATE TABLE TIPODEPENDENCIA (
    codDependencia int(9) not null auto_increment,
    tipoDependencia varchar(30) not null,
    constraint tipoPendencia_pk PRIMARY KEY (codDependencia)
)engine=InnoDB auto_increment=1;

CREATE TABLE DEPENDENTE (
    idDependente int(9) not null auto_increment,
    codDependencia int(9) not null,
    matriculaEmpregado bigint(11) not null,
    nome varchar(30) not null,
    dtNasc date not null,
    sexo enum('M','F') not null,
    constraint dependente_pk PRIMARY KEY (idDependente),
    constraint dependente_tipoDependencia_fk foreign key (codDependencia) references TIPODEPENDENCIA(codDependencia),
    constraint dependente_empregado_fk foreign key (matriculaEmpregado) references EMPREGADO (matricula)
)engine=InnoDB auto_increment=1;


CREATE TABLE PROJETO (
    codProjeto int(9) not null auto_increment,
    codDepartamento int(9) not null,
    nome varchar(30) not null,
    localizacao varchar(50) not null,
    constraint projeto_pk PRIMARY KEY (codProjeto),
    constraint projeto_departamento_fk foreign key (codDepartamento) references DEPARTAMENTO(codDepartamento)
)engine=InnoDB auto_increment=1;


CREATE TABLE trabalha (
    codProjeto int(9) not null,
    matricula bigint(11) not null,
    cargaHoraria int(2) not null,
	constraint trabalha_empregado_fk foreign key (matricula) references EMPREGADO(matricula),
    constraint trabalha_projeto_fk foreign key (codProjeto) references PROJETO(codProjeto)
)engine=InnoDB;


CREATE TABLE localizacao (
    codDepartamento int(9) not null,
    localizacao varchar(30) not null,
	constraint localizacao_departamento_fk foreign key (codDepartamento) references DEPARTAMENTO(codDepartamento)
)engine=InnoDB;

-- DROP DATABASE aula4exer7; 