﻿-- --------     << aula7exer2 >>     ------------ --
--                                                         --
--                    SCRIPT DE APAGA			   --
--                                                         --
-- Data Criacao ...........: 29/05/2018                    --
-- Autor(es) ..............: Andrew Lucas Guedes de Souza  --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: aula7exer2             --
--                                                         --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 07 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE aula7exer2;

DROP TABLE
ITEM,
NOTAFISCAL,
TELEFONE,
PERFUME,
MEDICAMENTO,
PRODUTO,
FABRICANTE;