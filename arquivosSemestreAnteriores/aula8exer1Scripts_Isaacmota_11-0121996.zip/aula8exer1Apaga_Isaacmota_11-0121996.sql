﻿-- --------     <<        aula8exer1             >>     ------------ --
--                                                                   --
--                    SCRIPT DE APAGA (DDL)                      --
--                                                                   --
-- Data Criacao ...........: 26/04/2018                              --
-- Autor(es) ..............: Isaac Borges Mota                       --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula8exer1                              --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 04 Tabelas                                             --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula8exer1;

DROP TABLE FORMADO;
DROP TABLE DISCIPLINA;
DROP TABLE ALUNO;
DROP TABLE CURSO;




