﻿-- --------     <<        aula8exer1             >>     ------------ --
--                                                                   --
--                    SCRIPT DE POPULACAO (DML)                      --
--                                                                   --
-- Data Criacao ...........: 26/04/2018                              --
-- Autor(es) ..............: Isaac Borges Mota                       --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula8exer1                              --
--                                                                   --
-- PROJETO => 01 Base de Dados                                       --
--         => 04 Tabelas                                             --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula8exer1;

INSERT INTO CURSO (nomeCurso,periodo) VALUES
 ('Engenharia','manhã'),
 ('Fisioterapia','tarde'),
 ('Medicina','tarde');


INSERT INTO DISCIPLINA VALUES
 (null,'Anatomia',4),
 (null, 'Algoritmo',6);


INSERT INTO FORMADO VALUES
 (10,100),
 (11,101),
 (10,101);


INSERT INTO ALUNO VALUES
 (111,123456,'Jose Carlos','2010-10-10',10),
 (222,654321,'Ana Maria','1990-02-22',11);



