-- --------     << aula4exer6Evolucao1 >>     ------------------------------- --
--                                                                   --
--                    SCRIPT DE CRIACAO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 20/04/2018                              --
-- Autor(es) ..............: Gustavo                 --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: exer6                                   --
--                                                                   --
-- PROJETO => Deleta todas a tabelas                                    --
--                                                                   --
--                                                                   --
--                                                                   --
-- ----------------------------------------------------------------- --
USE exer6;

drop table IF EXISTS INFRACAO;
drop table IF EXISTS VEICULO;
drop table IF EXISTS ENDERECO;
drop table IF EXISTS FONE;
drop table IF EXISTS PESSOA;
drop table IF EXISTS MODELO;
drop table IF EXISTS CATEGORIA;
drop table IF EXISTS LOCALL;
drop table IF EXISTS TIPO;
drop table IF EXISTS AGENTE;

