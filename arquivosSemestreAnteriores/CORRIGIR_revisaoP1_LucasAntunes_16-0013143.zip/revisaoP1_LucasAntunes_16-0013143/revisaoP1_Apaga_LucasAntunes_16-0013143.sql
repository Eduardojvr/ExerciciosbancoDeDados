﻿-- --------            << revisaoP1 >>        ------------ --
--                                                         --
--                    SCRIPT DE CRIACAO (DDL)              --
--                                                         --
-- Data Criacao ...........: 06/05/2018                    --
-- Autor(es) ..............: Lucas Penido Antunes          --
-- Banco de Dados .........: MySQL                         --
-- Banco de Dados(nome) ...: bdPhenix                      --
--                                                         --
-- Data Ultima Alteracao ..: 06/05/2018                    --
--   => Deleta todas as tabelas                            --
--                                                         --
-- PROJETO => 01 Base de Dados                             --
--         => 05 Tabelas                                   --
--                                                         --
-- ------------------------------------------------------- --

USE bdPhenix;

DROP TABLE trabalha;
DROP TABLE ENGENHEIRO;
DROP TABLE PROJETO;
DROP TABLE telefone;
DROP TABLE CLIENTE;
